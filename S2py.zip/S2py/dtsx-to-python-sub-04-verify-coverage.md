# dtsx-to-python — Sub-Agent 04: Verify Coverage

> Called by: `dtsx-to-python-orchestrator` → Stage 4: VERIFY
> AI Required: ❌ Never
> **Has COVERAGE GATE** — missing components loop back to sub-03

## Role
Compare the analysis (what the SSIS package does) against the generated code (what the Python does). Every single component in the analysis must have a corresponding function in the Python. If anything is missing, flag it and send it back.

## Mode
**Programmatic** — This is a diff between two structured artifacts. No judgment needed.

## Inputs
- Analysis files: `output/2-parse/*.analysis.json`
- Generated code: `output/3-code/*.py`

## Outputs
`output/4-verify/coverage_report.json`

```json
{
  "timestamp": "ISO-8601",
  "packages": [
    {
      "package": "LoadCustomerData",
      "analysis_file": "LoadCustomerData.analysis.json",
      "python_file": "LoadCustomerData.py",
      "compiles": true,
      "total_components": 19,
      "covered_components": 18,
      "missing_components": [
        {
          "task_id": "task-7",
          "type": "ScriptTask",
          "name": "Custom Date Validation",
          "reason": "No matching function found in generated code"
        }
      ],
      "placeholder_components": [
        {
          "task_id": "task-8",
          "type": "FuzzyLookup",
          "name": "Deduplicate Names",
          "reason": "Function exists but raises NotImplementedError"
        }
      ],
      "coverage_percent": 94.7
    }
  ],
  "overall": {
    "total_components": 54,
    "covered": 52,
    "missing": 1,
    "placeholder": 1,
    "coverage_percent": 96.3
  }
}
```

## Instructions

### Check 1: File Exists and Compiles
```
FOR each package in analysis:
    VERIFY {package_name}.py exists in output/3-code/
    RUN: python -m py_compile {file}
    IF missing or fails → CRITICAL
```

### Check 2: Component-by-Component Diff
```
FOR each package:
    LOAD analysis JSON
    LOAD Python file as text

    FOR each connection in analysis:
        SEARCH Python for: CONNECTIONS["{connection_name}"]
        IF not found → MISSING

    FOR each variable in analysis:
        SEARCH Python for variable name (User_BatchDate etc.)
        IF not found → MISSING

    FOR each task in control_flow:
        SEARCH Python for: def task_{id}_ or matching SSIS task name in comments
        IF not found → MISSING
        IF found but contains "NotImplementedError" → PLACEHOLDER

    FOR each transform in data_flows:
        SEARCH Python for comment matching transform name
        IF not found → MISSING

    FOR each destination in data_flows:
        SEARCH Python for: .to_sql("{table}") or .to_csv("{path}")
        IF not found → MISSING

    FOR each event_handler in analysis:
        SEARCH Python for corresponding try/except or notification function
        IF not found → MISSING

    CALCULATE: coverage = (total - missing - placeholder) / total × 100
```

### Check 3: SQL Preservation
```
FOR each SQL statement in analysis:
    FIND the same SQL in the Python file
    COMPARE character-by-character (ignoring whitespace differences)
    IF SQL differs → flag as "SQL_MODIFIED" (this should never happen in 1:1)
```

### Check 4: Execution Order
```
EXTRACT function call order from main() in the Python file
COMPARE against execution_order from analysis
IF order differs → flag as "ORDER_MISMATCH"
```

## Coverage Gate
```
IF any MISSING components → FAIL
    → Orchestrator sends missing list back to sub-03 (max 2 loops)

IF only PLACEHOLDER components → PASS WITH WARNINGS
    → These are known unsupported transforms, documented

IF 100% covered (no missing, no placeholder) → PASS
```

## Error Handling
- Python file doesn't exist → CRITICAL, all components count as missing
- Analysis file corrupt → skip package, flag in report

## Tools
- `ast` for parsing Python
- `re` for searching function definitions and comments
- `py_compile` for syntax check
- `json` for loading analysis
