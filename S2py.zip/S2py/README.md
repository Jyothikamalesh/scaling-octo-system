# SSIS-to-Python 1:1 Migration Agent Swarm

## Philosophy
**Exact functional replication + proof.** No optimization, no refactoring. If SSIS does X, Python does X. Then we prove it by running both against the same database and diffing the results.

## Pipeline

```
┌──────────────────────────────┐
│  dtsx-to-python-orchestrator │
└──────────────┬───────────────┘
               │
  ┌────────────┼────────────┐
  │            │            │
  ▼            ▼            ▼
sub-01       sub-02  ✋   sub-03        ← CODE GENERATION
scan         parse        generate
packages     logic        code
❌ no AI     🟡 scripts   🟡 scripts
  │            │            │
  └────────────┼────────────┘
               │
  ┌────────────┼────────────┐
  │            │            │
  ▼            ▼            ▼
sub-04       sub-05       sub-06  ✋    ← VERIFICATION + PROOF
verify       capture      prove
coverage     jobs         identical
❌ no AI     ❌ no AI     ❌ no AI
  ▲   │        │            │
  └───┘        │            │
  loop         └────────────┘
               │
               ▼
             sub-07                     ← REPORT
             write
             report
             ❌ no AI
               │
               ▼
            ✅ DONE
```

## Naming Convention

```
dtsx-to-python-orchestrator.md              →  Coordinates everything
dtsx-to-python-sub-01-scan-packages.md      →  Find .dtsx/.dtsconfig files
dtsx-to-python-sub-02-parse-logic.md        →  Extract what each package does
dtsx-to-python-sub-03-generate-code.md      →  1:1 Python translation
dtsx-to-python-sub-04-verify-coverage.md    →  Confirm nothing was missed
dtsx-to-python-sub-05-capture-jobs.md       →  Extract SQL Agent job definitions
dtsx-to-python-sub-06-prove-identical.md    →  THE PROOF: same DB state after both
dtsx-to-python-sub-07-write-report.md       →  Migration report with proof results
```

## The Proof (sub-06)

This is the key addition. It answers: **"Is the Python doing exactly what SSIS did?"**

```
1. Snapshot database state
2. Run SSIS package (via SQL Agent job)
3. Snapshot database state after SSIS
4. Restore database to original state
5. Run Python script
6. Snapshot database state after Python
7. Diff the two "after" snapshots row-by-row
8. Verdict: IDENTICAL ✅ or differences listed ❌
```

No opinions. No test cases. Just: run both, compare the actual database.

## AI Usage

```
Sub-Agent    AI?         When
─────────    ───         ────
sub-01       ❌ Never    File scanning
sub-02       🟡 Rare     Only for C# Script Tasks
sub-03       🟡 Rare     Only for C# Script Tasks
sub-04       ❌ Never    Diff: analysis vs code
sub-05       ❌ Never    Query msdb system tables
sub-06       ❌ Never    Snapshot + diff — pure SQL and pandas
sub-07       ❌ Never    Aggregation

~90% programmatic. AI only touches Script Tasks.
```

## Output Structure

```
output/
├── 1-scan/
│   └── manifest.json
├── 2-parse/
│   └── {package_name}.analysis.json
├── 3-code/
│   ├── config.py
│   ├── requirements.txt
│   └── {package_name}.py
├── 4-verify/
│   └── coverage_report.json
├── 5-jobs/
│   └── agent_jobs.json
├── 6-prove/
│   ├── proof_report.json
│   ├── snapshots/
│   │   ├── before/
│   │   ├── after_ssis/
│   │   └── after_python/
│   └── diffs/          ← only if differences found
└── 7-report/
    └── migration_report.md
```

## Prerequisites for Proof Stage
- Read access to source databases
- Write access to destination databases (or a test copy)
- Permission to trigger SQL Agent jobs (`sp_start_job`)
- Permission to create/restore database snapshots (or truncate+reload)
- The SSIS packages must still be deployed and working
