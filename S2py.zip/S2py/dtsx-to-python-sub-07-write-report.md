# dtsx-to-python — Sub-Agent 07: Write Report

> Called by: `dtsx-to-python-orchestrator` → Stage 7: REPORT
> AI Required: ❌ Never

## Role
Compile the migration report. What was in SSIS, what's now in Python, the 1:1 mapping, the Agent job mapping, and the proof results.

## Mode
**Programmatic** — Reads all previous outputs, assembles into markdown.

## Inputs
- `output/1-scan/manifest.json`
- `output/2-parse/*.analysis.json`
- `output/3-code/*.py`
- `output/4-verify/coverage_report.json`
- `output/5-jobs/agent_jobs.json`
- `output/6-prove/proof_report.json`

## Outputs
- `output/7-report/migration_report.md`

## Report Template

```markdown
# SSIS → Python 1:1 Migration Report

**Generated:** {timestamp}

## Summary

| Metric                   | Count |
|--------------------------|-------|
| SSIS packages found      | {n}   |
| Python files generated   | {n}   |
| Total SSIS components    | {n}   |
| Components covered       | {n}   |
| Placeholders (manual)    | {n}   |
| SQL Agent jobs captured  | {n}   |
| Proof tests run          | {n}   |
| Proof tests IDENTICAL    | {n}   |
| Proof tests FAILED       | {n}   |

---

## Proof Results

| Package | Job Name | Tables Tested | All Identical? |
|---------|----------|---------------|----------------|
| LoadCustomerData | ETL_Load_Customer_Data | 3 | ✅ |
| LoadOrders | ETL_Nightly_Full (step 2) | 2 | ✅ |

### Table-Level Detail
| Package | Table | SSIS Rows | Python Rows | Match | Value Diffs |
|---------|-------|-----------|-------------|-------|-------------|
| LoadCustomerData | stg.Customers_US | 1,234 | 1,234 | ✅ | 0 |
| LoadCustomerData | stg.Customers_EU | 567 | 567 | ✅ | 0 |
| LoadCustomerData | errors.csv | 12 | 12 | ✅ | 0 |

### Excluded from Comparison
| Column | Reason |
|--------|--------|
| LoadDate | Uses GETDATE() — differs by execution time |

---

## Package Mapping

### {PackageName}.dtsx → {PackageName}.py

| # | SSIS Task | Type | Python Function | Status |
|---|-----------|------|-----------------|--------|
| 1 | Truncate Staging | ExecuteSQLTask | task_1_truncate_staging_table() | ✅ |
| 2 | Load Customers | DataFlowTask | task_2_load_customer_data() | ✅ |
| 3 | Custom Validation | ScriptTask | task_7_custom_date_validation() | ⚠️ AI |

---

## Agent Job Mapping

### {JobName} → {python equivalent}

| Step | SSIS Step | Subsystem | Python Equivalent | Schedule |
|------|-----------|-----------|-------------------|----------|
| 1 | Run SSIS Package | SSIS | python LoadCustomerData.py | 0 6 * * * |
| 2 | Run Validation | TSQL | (keep as-is, runs against same DB) | |

---

## Items Requiring Manual Work

| Package | Component | Type | Reason |
|---------|-----------|------|--------|
| ... | ... | ... | ... |

## Files Generated

```
output/3-code/
├── config.py
├── requirements.txt
├── LoadCustomerData.py
└── LoadOrders.py
```
```

## Tools
- `json` for reading inputs
- String formatting for markdown
