# dtsx-to-python — Sub-Agent 02: Parse Logic

> Called by: `dtsx-to-python-orchestrator` → Stage 2: PARSE
> AI Required: 🟡 Rare — only for Script Tasks containing C#/VB.NET

## Role
Deep-parse each SSIS package and extract **exactly** what it does. Every connection, every variable, every task, every transform, every precedence constraint, every event handler — in the exact order SSIS executes them. No interpretation, no simplification. Record the raw facts.

## Mode
**Hybrid** — XML extraction is programmatic. Script Tasks with embedded C#/VB.NET need AI to describe what the code does.

## Inputs
- Manifest: `output/1-scan/manifest.json`
- Raw .dtsx and .dtsconfig files

## Outputs
One file per package: `output/2-parse/{package_name}.analysis.json`

```json
{
  "package_name": "LoadCustomerData",
  "connections": [
    {
      "id": "conn-1",
      "name": "SourceDB",
      "type": "OLEDB",
      "connection_string": "Server=prod-sql;Database=CustomerDB;...",
      "from_config": true
    }
  ],
  "variables": [
    {
      "name": "User::BatchDate",
      "namespace": "User",
      "type": "DateTime",
      "value": "2024-01-01",
      "expression": "@[System::StartTime]",
      "evaluate_as_expression": true,
      "used_in": ["task-1", "task-3"]
    }
  ],
  "execution_order": ["task-1", "task-2", "task-3"],
  "control_flow": [
    {
      "task_id": "task-1",
      "type": "ExecuteSQLTask",
      "name": "Truncate Staging Table",
      "connection_ref": "conn-1",
      "sql_statement": "TRUNCATE TABLE stg.Customers",
      "result_set": "none",
      "parameter_mappings": []
    },
    {
      "task_id": "task-2",
      "type": "DataFlowTask",
      "name": "Load Customer Data",
      "data_flow": {
        "source": {
          "type": "OLEDBSource",
          "connection_ref": "conn-1",
          "access_mode": "SQLCommand",
          "sql": "SELECT CustomerID, Name, Email FROM dbo.Customers WHERE Active = 1",
          "output_columns": [
            {"name": "CustomerID", "type": "DT_I4"},
            {"name": "Name", "type": "DT_WSTR", "length": 100},
            {"name": "Email", "type": "DT_WSTR", "length": 255}
          ]
        },
        "transforms": [
          {
            "order": 1,
            "type": "DerivedColumn",
            "name": "Add LoadDate",
            "columns": [
              {
                "output_name": "LoadDate",
                "expression": "GETDATE()",
                "type": "DT_DBTIMESTAMP",
                "replace_existing": false
              }
            ]
          },
          {
            "order": 2,
            "type": "Lookup",
            "name": "Lookup Region",
            "connection_ref": "conn-1",
            "lookup_sql": "SELECT CustomerID, Region FROM dbo.CustomerRegions",
            "join_columns": [{"input": "CustomerID", "lookup": "CustomerID"}],
            "output_columns": [{"lookup": "Region", "alias": "Region"}],
            "no_match_behavior": "redirect_to_no_match_output",
            "cache_mode": "Full"
          },
          {
            "order": 3,
            "type": "ConditionalSplit",
            "name": "Split by Region",
            "conditions": [
              {"output_name": "US_Customers", "expression": "Region == \"US\"", "order": 1},
              {"output_name": "EU_Customers", "expression": "Region == \"UK\" || Region == \"DE\" || Region == \"FR\"", "order": 2}
            ],
            "default_output": "Default"
          }
        ],
        "destinations": [
          {
            "type": "OLEDBDestination",
            "connection_ref": "conn-2",
            "table": "stg.Customers_US",
            "receives_from": "US_Customers",
            "column_mappings": [
              {"source": "CustomerID", "dest": "CustID"},
              {"source": "Name", "dest": "FullName"},
              {"source": "LoadDate", "dest": "LoadDate"},
              {"source": "Region", "dest": "Region"}
            ],
            "access_mode": "OpenRowset Using FastLoad",
            "fast_load_options": "TABLOCK,CHECK_CONSTRAINTS"
          }
        ],
        "error_output": {
          "type": "FlatFileDestination",
          "path": "//server/errors/customer_errors.csv",
          "receives_from": "Lookup.NoMatch"
        }
      }
    }
  ],
  "precedence_constraints": [
    {
      "from": "task-1",
      "to": "task-2",
      "eval_op": "Constraint",
      "value": "Success",
      "expression": null
    }
  ],
  "event_handlers": [
    {
      "event": "OnError",
      "scope": "package",
      "tasks": [
        {
          "type": "SendMailTask",
          "smtp_connection": "conn-smtp",
          "to": "ops-team@company.com",
          "subject": "ETL Failure: LoadCustomerData",
          "body": "Package failed. Check logs."
        }
      ]
    }
  ],
  "script_tasks": [
    {
      "task_id": "task-5",
      "language": "CSharp",
      "entry_point": "ScriptMain.Main",
      "readonly_variables": ["User::BatchDate"],
      "readwrite_variables": ["User::IsValid"],
      "code": "public void Main() { ... full code ... }",
      "ai_analysis": "Validates BatchDate against a business calendar table. Sets IsValid to true/false."
    }
  ],
  "component_count": {
    "connections": 3,
    "variables": 5,
    "control_flow_tasks": 4,
    "data_flow_transforms": 3,
    "destinations": 2,
    "event_handlers": 1,
    "script_tasks": 1,
    "total": 19
  }
}
```

## Instructions

### Step 1: Parse Connection Managers
```
FOR each <DTS:ConnectionManager>:
    EXTRACT: name, CreationName (type), ConnectionString
    CHECK .dtsconfig for overridden values — use those if present
    RECORD exactly as-is. Do not modify connection strings.
```

### Step 2: Parse Variables
```
FOR each <DTS:Variable>:
    EXTRACT: Namespace, Name, DataType, Value, Expression, EvaluateAsExpression
    TRACE which tasks reference this variable
    RECORD the raw SSIS expression string — do not translate it yet
```

### Step 3: Parse Control Flow
```
FOR each <DTS:Executable>:
    IDENTIFY type via CreationName GUID
    EXTRACT every property the task has:
        - ExecuteSQLTask: SQL, connection, result set, parameter mappings
        - DataFlowTask: link to pipeline definition
        - FileSystemTask: operation, source path, dest path
        - ExecutePackageTask: child package path
        - ScriptTask: language, code, variables
        - SendMailTask: connection, to, subject, body
        - ForLoop: init expression, eval expression, assign expression
        - ForeachLoop: enumerator type, variable mappings
        - SequenceContainer: child task list
    RECORD everything. Leave nothing out.
```

### Step 4: Parse Data Flows
```
FOR each DataFlowTask pipeline:
    EXTRACT source components:
        - Type, connection, SQL or table, output columns with exact SSIS data types
    EXTRACT transforms IN ORDER:
        - DerivedColumn: every column expression exactly as written in SSIS
        - Lookup: SQL, join columns, output columns, cache mode, no-match behavior
        - ConditionalSplit: every condition expression exactly as written
        - Sort: columns, sort direction
        - Aggregate: group-by columns, aggregation operations
        - UnionAll: input mappings
        - Multicast: output count
        - DataConversion: source type, dest type per column
        - RowCount: target variable
        - OLEDBCommand: SQL, parameter mappings
        - Any other transform: record type + all properties
    EXTRACT destinations:
        - Type, connection, table, column mappings, fast load options
    EXTRACT error outputs:
        - Where error rows go, which component's errors
    PRESERVE exact column lineage through the entire flow
```

### Step 5: Parse Precedence Constraints
```
FOR each <DTS:PrecedenceConstraint>:
    EXTRACT: from task, to task, Value (Success/Failure/Completion)
    EXTRACT: EvalOp, Expression (if expression-based)
    BUILD execution order via topological sort
    RECORD the raw expression — do not simplify
```

### Step 6: Parse Event Handlers
```
FOR each <DTS:EventHandler>:
    EXTRACT: event type, scope (package/task)
    EXTRACT: all tasks within the handler (same parsing as control flow)
```

### Step 7: Handle Script Tasks (AI)
```
FOR each ScriptTask:
    EXTRACT: language, entry point, full source code
    EXTRACT: readonly and readwrite variable lists
    SEND to AI:
        "What does this code do? Describe the exact logic step by step.
         Do not suggest improvements. Just describe what it does."
    STORE the AI description alongside the raw code
```

### Step 8: Count Components
```
COUNT every component extracted
THIS IS THE CHECKLIST that sub-04 will verify against
```

## Error Handling
- Unknown task GUID → record as "UNKNOWN:{guid}", include raw XML
- Malformed expression → store raw string, flag as unparseable
- Encrypted package → fail, request decrypted version
- Binary script → flag as "BINARY_SCRIPT_MANUAL_REVIEW"

## Tools
- `lxml` for XML parsing with namespaces
- `networkx` for topological sort of execution order
- AI API for Script Task descriptions only
