# dtsx-to-python — Sub-Agent 05: Capture Jobs

> Called by: `dtsx-to-python-orchestrator` → Stage 5: CAPTURE JOBS
> AI Required: ❌ Never
> Inserted BEFORE comparison — we need to know what triggers what

## Role
Extract every SQL Server Agent job that triggers SSIS packages. Record the exact schedule, step order, step configuration, and which .dtsx each step calls. This is the "trigger layer" — the Python replacement needs to be called the same way.

## Mode
**Programmatic** — Query the msdb system tables. No AI needed.

## Inputs
- Database connection (with access to msdb)
- Package manifest: `output/1-scan/manifest.json` (to match jobs → packages)

## Outputs
`output/5-jobs/agent_jobs.json`

```json
{
  "server": "prod-sql-01",
  "jobs": [
    {
      "job_id": "uuid",
      "job_name": "ETL_Load_Customer_Data",
      "enabled": true,
      "description": "Daily customer data load",
      "owner": "sa",
      "schedule": {
        "name": "Daily_6AM",
        "frequency": "daily",
        "time": "06:00:00",
        "cron_equivalent": "0 6 * * *"
      },
      "steps": [
        {
          "step_id": 1,
          "step_name": "Run SSIS Package",
          "subsystem": "SSIS",
          "package_path": "\\SSISDB\\CustomerETL\\LoadCustomerData.dtsx",
          "package_name": "LoadCustomerData.dtsx",
          "python_equivalent": "LoadCustomerData.py",
          "command": "/ISSERVER \"\\SSISDB\\...\" /SERVER prod-sql-01 /Par \"$ServerOption::LOGGING_LEVEL(Int16)\";1",
          "on_success": "go_to_next_step",
          "on_failure": "quit_with_failure",
          "retry_attempts": 0,
          "retry_interval_minutes": 0
        },
        {
          "step_id": 2,
          "step_name": "Run Validation",
          "subsystem": "TSQL",
          "database": "CustomerDB",
          "command": "EXEC dbo.sp_ValidateCustomerLoad",
          "on_success": "quit_with_success",
          "on_failure": "quit_with_failure"
        }
      ],
      "notifications": {
        "on_failure": {
          "notify_type": "email",
          "operator": "DBA_Team"
        }
      }
    }
  ],
  "job_to_package_map": {
    "ETL_Load_Customer_Data": ["LoadCustomerData.dtsx"],
    "ETL_Nightly_Full": ["LoadCustomerData.dtsx", "LoadOrders.dtsx", "SharedLookups.dtsx"]
  }
}
```

## SQL to Extract Jobs

```sql
-- Run this against msdb on the target server

-- 1. All jobs that have SSIS steps
SELECT
    j.job_id,
    j.name AS job_name,
    j.enabled,
    j.description,
    SUSER_SNAME(j.owner_sid) AS owner
FROM msdb.dbo.sysjobs j
WHERE EXISTS (
    SELECT 1 FROM msdb.dbo.sysjobsteps s
    WHERE s.job_id = j.job_id
    AND s.subsystem IN ('SSIS', 'CmdExec')  -- CmdExec may call dtexec
    AND (s.command LIKE '%dtsx%' OR s.command LIKE '%ISSERVER%' OR s.command LIKE '%dtexec%')
);

-- 2. Job steps
SELECT
    s.job_id,
    s.step_id,
    s.step_name,
    s.subsystem,
    s.command,
    s.database_name,
    s.on_success_action,
    s.on_fail_action,
    s.retry_attempts,
    s.retry_interval
FROM msdb.dbo.sysjobsteps s
JOIN msdb.dbo.sysjobs j ON j.job_id = s.job_id
ORDER BY j.name, s.step_id;

-- 3. Schedules
SELECT
    j.name AS job_name,
    sch.name AS schedule_name,
    sch.freq_type,        -- 1=once, 4=daily, 8=weekly, 16=monthly
    sch.freq_interval,
    sch.active_start_time -- HHMMSS as integer
FROM msdb.dbo.sysjobs j
JOIN msdb.dbo.sysjobschedules js ON js.job_id = j.job_id
JOIN msdb.dbo.sysschedules sch ON sch.schedule_id = js.schedule_id;

-- 4. Notifications
SELECT
    j.name AS job_name,
    j.notify_level_email,
    j.notify_level_page,
    o.name AS operator_name,
    o.email_address AS operator_email
FROM msdb.dbo.sysjobs j
LEFT JOIN msdb.dbo.sysoperators o ON o.id = j.notify_email_operator_id;
```

## Instructions

### Step 1: Query msdb
```
CONNECT to the SQL Server using provided credentials
RUN the four queries above
PARSE results into structured format
```

### Step 2: Extract Package References from Steps
```
FOR each job step where subsystem = 'SSIS':
    PARSE the command string to extract:
        - Package path (from /ISSERVER or /FILE flag)
        - Server (from /SERVER flag)
        - Parameters (from /Par flags)
        - Environment reference (from /ENVREFERENCE flag)

FOR each job step where subsystem = 'CmdExec':
    CHECK if command contains 'dtexec'
    IF yes: parse same flags from dtexec command line
```

### Step 3: Map Jobs to Packages
```
FOR each extracted package path:
    MATCH to a package in manifest.json by filename
    IF match found → record the mapping
    IF no match → flag as "package not in repo"
```

### Step 4: Convert Schedules to Cron
```
MAP SQL Agent frequency to cron expression:
    freq_type=4 (daily) + active_start_time=060000 → "0 6 * * *"
    freq_type=8 (weekly) + freq_interval=2 (Mon) → "0 6 * * 1"
    freq_type=16 (monthly) + freq_interval=1 → "0 6 1 * *"
```

### Step 5: Record Step Order and Flow
```
FOR each job:
    RECORD step execution order
    RECORD on_success / on_failure actions:
        1 = quit with success
        2 = quit with failure
        3 = go to next step
        4 = go to step N
    THIS becomes the equivalent Python orchestration logic
```

## Error Handling
- No msdb access → fail with clear error, request permissions
- Job references package not in manifest → flag, don't fail

## Tools
- `pyodbc` or `sqlalchemy` for database queries
- `json` for output
