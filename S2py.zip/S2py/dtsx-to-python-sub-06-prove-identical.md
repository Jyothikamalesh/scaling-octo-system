# dtsx-to-python — Sub-Agent 06: Prove Identical

> Called by: `dtsx-to-python-orchestrator` → Stage 6: PROVE
> AI Required: ❌ Never
> This is the foolproof test. No opinions. Just: did the DB end up in the same state?

## Role
Prove that the SSIS package and the Python script produce **the exact same database state** when given the exact same starting point. Uses real database, real data, real connections. Snapshot before, snapshot after, diff.

## Mode
**Programmatic** — SQL queries + pandas diff. No AI.

## The Method

```
┌─────────────────────────────────────────────────────────────────────┐
│                     THE PROOF                                        │
│                                                                      │
│   ┌──────────┐     ┌──────────────┐     ┌──────────────────┐       │
│   │ SNAPSHOT  │     │  RUN SSIS    │     │  SNAPSHOT        │       │
│   │ BEFORE    │────▶│  (Agent job) │────▶│  AFTER SSIS      │       │
│   │ (all dest │     │              │     │  (all dest       │       │
│   │  tables)  │     └──────────────┘     │   tables)        │       │
│   └──────────┘                           └────────┬─────────┘       │
│        │                                          │                  │
│        │              ┌──────────────┐            │                  │
│        │              │  RESTORE DB  │            │                  │
│        └─────────────▶│  to BEFORE   │            │                  │
│                       │  state       │            │                  │
│                       └──────┬───────┘            │                  │
│                              │                    │                  │
│                              ▼                    │                  │
│   ┌──────────┐     ┌──────────────┐     ┌────────┴─────────┐       │
│   │ (same     │     │  RUN PYTHON  │     │  SNAPSHOT        │       │
│   │  BEFORE   │────▶│  (.py file)  │────▶│  AFTER PYTHON    │       │
│   │  state)   │     │              │     │  (all dest       │       │
│   └──────────┘     └──────────────┘     │   tables)        │       │
│                                          └────────┬─────────┘       │
│                                                   │                  │
│                                                   ▼                  │
│                                          ┌──────────────────┐       │
│                            AFTER SSIS    │     DIFF          │       │
│                          ─────────────── │                   │       │
│                            AFTER PYTHON  │  Row-by-row       │       │
│                                          │  Column-by-column │       │
│                                          │                   │       │
│                                          │  IDENTICAL? ✅❌  │       │
│                                          └──────────────────┘       │
└─────────────────────────────────────────────────────────────────────┘
```

## Inputs
- Generated Python code: `output/3-code/*.py`
- Analysis files: `output/2-parse/*.analysis.json` (to know which tables to snapshot)
- Job definitions: `output/5-jobs/agent_jobs.json` (to know how to trigger SSIS)
- Database connection credentials

## Outputs
- `output/6-prove/proof_report.json`
- `output/6-prove/snapshots/` (CSVs of before/after states)
- `output/6-prove/diffs/` (any row-level differences found)

## Proof Report Format
```json
{
  "timestamp": "ISO-8601",
  "server": "prod-sql-01",
  "packages_tested": [
    {
      "package": "LoadCustomerData",
      "ssis_job": "ETL_Load_Customer_Data",
      "python_file": "LoadCustomerData.py",
      "tables_compared": [
        {
          "table": "stg.Customers_US",
          "ssis_row_count": 1234,
          "python_row_count": 1234,
          "row_count_match": true,
          "column_count_match": true,
          "value_mismatches": 0,
          "rows_only_in_ssis": 0,
          "rows_only_in_python": 0,
          "is_identical": true
        },
        {
          "table": "stg.Customers_EU",
          "ssis_row_count": 567,
          "python_row_count": 567,
          "is_identical": true
        }
      ],
      "files_compared": [
        {
          "path": "//server/errors/customer_errors.csv",
          "ssis_row_count": 12,
          "python_row_count": 12,
          "is_identical": true
        }
      ],
      "verdict": "IDENTICAL"
    }
  ],
  "overall_verdict": "ALL IDENTICAL"
}
```

## Instructions

### Step 1: Identify What to Snapshot

```
FROM the analysis files, extract EVERY destination:
    - OLE DB Destinations → table name + schema + connection
    - Flat File Destinations → file path
    - Excel Destinations → file path + sheet

FROM the analysis files, extract EVERY table that gets modified:
    - TRUNCATE statements in ExecuteSQLTask
    - INSERT/UPDATE/DELETE in ExecuteSQLTask
    - Destination tables in DataFlowTasks

BUILD the snapshot list:
    snapshot_tables = [
        {"connection": "TargetDB", "table": "stg.Customers_US", "key_columns": ["CustID"]},
        {"connection": "TargetDB", "table": "stg.Customers_EU", "key_columns": ["CustID"]},
    ]
    snapshot_files = [
        {"path": "//server/errors/customer_errors.csv"}
    ]
```

### Step 2: Snapshot BEFORE State

```python
def snapshot_table(connection_string, table, snapshot_path):
    """Dump entire table to CSV."""
    engine = create_engine(connection_string)
    df = pd.read_sql(f"SELECT * FROM {table}", engine)
    df.to_csv(snapshot_path, index=False)
    return len(df)

def snapshot_all_targets(snapshot_dir):
    """Snapshot every destination table and file."""
    os.makedirs(snapshot_dir, exist_ok=True)
    for tbl in snapshot_tables:
        snapshot_table(
            CONNECTIONS[tbl["connection"]],
            tbl["table"],
            f"{snapshot_dir}/{tbl['table'].replace('.', '_')}.csv"
        )
    for f in snapshot_files:
        if os.path.exists(f["path"]):
            shutil.copy(f["path"], f"{snapshot_dir}/")

# Take BEFORE snapshot
snapshot_all_targets("output/6-prove/snapshots/before/")
```

### Step 3: Run SSIS Package (via Agent Job)

```python
def run_ssis_job(server, job_name, timeout_minutes=30):
    """Trigger the SQL Agent job and wait for it to finish."""
    engine = create_engine(f"mssql+pyodbc://{server}/msdb?...")

    with engine.connect() as conn:
        # Start the job
        conn.execute(text(f"EXEC msdb.dbo.sp_start_job @job_name = '{job_name}'"))
        conn.commit()

        # Poll until complete
        start = time.time()
        while time.time() - start < timeout_minutes * 60:
            result = conn.execute(text("""
                SELECT TOP 1
                    run_status,
                    run_duration,
                    message
                FROM msdb.dbo.sysjobhistory
                WHERE job_id = (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = :job_name)
                AND step_id = 0  -- step 0 = overall job outcome
                ORDER BY run_date DESC, run_time DESC
            """), {"job_name": job_name}).fetchone()

            if result and result.run_status in (0, 1):  # 0=failed, 1=succeeded
                return {
                    "status": "success" if result.run_status == 1 else "failed",
                    "duration": result.run_duration,
                    "message": result.message
                }
            time.sleep(5)

        return {"status": "timeout"}

# Run SSIS
ssis_result = run_ssis_job("prod-sql-01", "ETL_Load_Customer_Data")
```

### Step 4: Snapshot AFTER SSIS

```python
snapshot_all_targets("output/6-prove/snapshots/after_ssis/")
```

### Step 5: Restore DB to BEFORE State

```
THREE OPTIONS (choose based on your environment):

OPTION A: Re-run the TRUNCATE + reload from snapshot (simplest)
    FOR each destination table:
        TRUNCATE TABLE {table}
        BULK INSERT from the BEFORE snapshot CSV
    FOR each destination file:
        Delete or overwrite with BEFORE version

OPTION B: Database restore from backup
    RESTORE DATABASE {db} FROM DISK = '{backup_path}' WITH REPLACE
    (requires a backup taken at BEFORE snapshot time)

OPTION C: Use database snapshots (SQL Server feature)
    -- Before the whole test:
    CREATE DATABASE {db}_snapshot ON
        (NAME = {db}, FILENAME = '{path}')
    AS SNAPSHOT OF {db};

    -- After SSIS run, restore from snapshot:
    RESTORE DATABASE {db} FROM DATABASE_SNAPSHOT = '{db}_snapshot';

    -- This puts the DB back to EXACTLY the before state
    -- Then run Python against this identical starting point
```

```python
def restore_to_before_state(method="snapshot"):
    if method == "snapshot":
        engine = create_engine(CONNECTIONS["TargetDB"])
        with engine.connect() as conn:
            conn.execute(text(f"RESTORE DATABASE TargetDB FROM DATABASE_SNAPSHOT = 'TargetDB_snapshot'"))
            conn.commit()

    elif method == "truncate_reload":
        engine = create_engine(CONNECTIONS["TargetDB"])
        for tbl in snapshot_tables:
            before_df = pd.read_csv(f"output/6-prove/snapshots/before/{tbl['table'].replace('.', '_')}.csv")
            with engine.connect() as conn:
                conn.execute(text(f"TRUNCATE TABLE {tbl['table']}"))
                conn.commit()
            before_df.to_sql(
                tbl["table"].split(".")[-1],
                engine,
                schema=tbl["table"].split(".")[0],
                if_exists="append",
                index=False
            )
```

### Step 6: Run Python Script

```python
def run_python_script(script_path):
    """Run the generated Python script."""
    import subprocess
    result = subprocess.run(
        ["python", script_path],
        capture_output=True,
        text=True,
        timeout=1800  # 30 min timeout
    )
    return {
        "status": "success" if result.returncode == 0 else "failed",
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode
    }

python_result = run_python_script("output/3-code/LoadCustomerData.py")
```

### Step 7: Snapshot AFTER PYTHON

```python
snapshot_all_targets("output/6-prove/snapshots/after_python/")
```

### Step 8: DIFF — The Proof

```python
def diff_snapshots(after_ssis_dir, after_python_dir, key_columns_map):
    """Compare every table: SSIS after-state vs Python after-state."""
    results = []

    for tbl in snapshot_tables:
        table_name = tbl["table"].replace(".", "_")
        key_cols = tbl["key_columns"]

        ssis_df = pd.read_csv(f"{after_ssis_dir}/{table_name}.csv")
        python_df = pd.read_csv(f"{after_python_dir}/{table_name}.csv")

        result = {
            "table": tbl["table"],
            "ssis_row_count": len(ssis_df),
            "python_row_count": len(python_df),
            "row_count_match": len(ssis_df) == len(python_df),
        }

        # Column check
        result["ssis_columns"] = sorted(ssis_df.columns.tolist())
        result["python_columns"] = sorted(python_df.columns.tolist())
        result["column_count_match"] = result["ssis_columns"] == result["python_columns"]

        if not result["column_count_match"]:
            result["is_identical"] = False
            results.append(result)
            continue

        # Row-by-row comparison
        # Normalize types to string for comparison (avoids float precision issues)
        ssis_norm = ssis_df.astype(str).sort_values(key_cols).reset_index(drop=True)
        python_norm = python_df.astype(str).sort_values(key_cols).reset_index(drop=True)

        if ssis_norm.equals(python_norm):
            result["value_mismatches"] = 0
            result["is_identical"] = True
        else:
            # Find exactly which rows differ
            merged = ssis_norm.merge(
                python_norm, on=key_cols, how="outer",
                suffixes=("_ssis", "_python"), indicator=True
            )
            only_ssis = merged[merged["_merge"] == "left_only"]
            only_python = merged[merged["_merge"] == "right_only"]
            both = merged[merged["_merge"] == "both"]

            # Check value differences in matched rows
            value_diffs = []
            for col in ssis_df.columns:
                if col in key_cols:
                    continue
                sc, pc = f"{col}_ssis", f"{col}_python"
                if sc in both.columns and pc in both.columns:
                    mismatches = both[both[sc] != both[pc]]
                    if len(mismatches) > 0:
                        # Save diff detail
                        diff_detail = mismatches[key_cols + [sc, pc]].head(20)
                        diff_detail.to_csv(
                            f"output/6-prove/diffs/{table_name}_{col}_diffs.csv",
                            index=False
                        )
                        value_diffs.append({
                            "column": col,
                            "diff_count": len(mismatches),
                            "diff_file": f"diffs/{table_name}_{col}_diffs.csv"
                        })

            result["rows_only_in_ssis"] = len(only_ssis)
            result["rows_only_in_python"] = len(only_python)
            result["value_mismatches"] = value_diffs
            result["is_identical"] = (
                len(only_ssis) == 0
                and len(only_python) == 0
                and len(value_diffs) == 0
            )

        results.append(result)

    return results

# THE PROOF
table_results = diff_snapshots(
    "output/6-prove/snapshots/after_ssis/",
    "output/6-prove/snapshots/after_python/",
    {tbl["table"]: tbl["key_columns"] for tbl in snapshot_tables}
)

# Also compare output files
file_results = []
for f in snapshot_files:
    fname = os.path.basename(f["path"])
    ssis_file = f"output/6-prove/snapshots/after_ssis/{fname}"
    python_file = f"output/6-prove/snapshots/after_python/{fname}"
    if os.path.exists(ssis_file) and os.path.exists(python_file):
        ssis_df = pd.read_csv(ssis_file)
        python_df = pd.read_csv(python_file)
        file_results.append({
            "path": f["path"],
            "ssis_row_count": len(ssis_df),
            "python_row_count": len(python_df),
            "is_identical": ssis_df.astype(str).equals(python_df.astype(str))
        })

# VERDICT
all_identical = (
    all(t["is_identical"] for t in table_results)
    and all(f["is_identical"] for f in file_results)
)

print("=" * 60)
if all_identical:
    print("  ✅ PROOF: SSIS and Python produce IDENTICAL results")
else:
    print("  ❌ PROOF FAILED: Differences found")
    for t in table_results:
        if not t["is_identical"]:
            print(f"    Table {t['table']}:")
            print(f"      Rows: SSIS={t['ssis_row_count']} Python={t['python_row_count']}")
            if t.get("value_mismatches"):
                for vm in t["value_mismatches"]:
                    print(f"      Column '{vm['column']}': {vm['diff_count']} rows differ")
                    print(f"        See: {vm['diff_file']}")
print("=" * 60)
```

## Known Gotchas and How to Handle Them

### Timestamps / GETDATE()
```
PROBLEM:  SSIS runs at 06:00:01, Python runs at 06:05:32.
          Any column using GETDATE() will have different values.

SOLUTION: Before comparing, EXCLUDE timestamp columns that use GETDATE():
          - Identify these from the analysis (DerivedColumn with GETDATE())
          - Drop them from both DataFrames before comparison
          - Log: "Excluded LoadDate column (uses GETDATE(), will differ by execution time)"
          - OR: Compare only the date portion, not the time
```

### Row Ordering
```
PROBLEM:  SSIS and Python may insert rows in different order.
          Same data, different physical row sequence.

SOLUTION: Always sort both DataFrames by key columns before comparing.
          Already handled in the diff function above.
```

### Float Precision
```
PROBLEM:  SSIS: 123.4567890000  Python: 123.45678900001
          Floating point rounding differs between engines.

SOLUTION: Round numeric columns to N decimal places before comparing.
          df[col] = df[col].round(6)
```

### NULL vs Empty String
```
PROBLEM:  SSIS writes NULL, Python writes "" (or vice versa).

SOLUTION: Normalize both: df = df.fillna("").replace("None", "")
          Then compare.
```

### Identity / Auto-Increment Columns
```
PROBLEM:  SSIS inserts get IDENTITY values 1001-1234,
          Python inserts get IDENTITY values 2001-2234.

SOLUTION: Exclude IDENTITY columns from value comparison.
          Compare only on business key columns.
```

### File Encoding
```
PROBLEM:  SSIS writes Windows-1252, Python writes UTF-8.

SOLUTION: Read both with explicit encoding detection.
          Compare content, not bytes.
```

## Full Test Sequence (Copy-Paste Ready)

```bash
# 1. Take DB snapshot (SQL Server)
sqlcmd -S prod-sql-01 -Q "CREATE DATABASE TargetDB_proof_snapshot ON (NAME=TargetDB, FILENAME='D:\snapshots\proof.ss') AS SNAPSHOT OF TargetDB"

# 2. Run SSIS via Agent job
sqlcmd -S prod-sql-01 -Q "EXEC msdb.dbo.sp_start_job 'ETL_Load_Customer_Data'"
# Wait for completion...

# 3. Snapshot AFTER SSIS
python prove_identical.py --step snapshot_after_ssis

# 4. Restore from snapshot
sqlcmd -S prod-sql-01 -Q "RESTORE DATABASE TargetDB FROM DATABASE_SNAPSHOT = 'TargetDB_proof_snapshot'"

# 5. Run Python
python output/3-code/LoadCustomerData.py

# 6. Snapshot AFTER PYTHON
python prove_identical.py --step snapshot_after_python

# 7. DIFF
python prove_identical.py --step diff

# 8. Cleanup
sqlcmd -S prod-sql-01 -Q "DROP DATABASE TargetDB_proof_snapshot"
```

## Error Handling
- Can't create DB snapshot → fall back to truncate+reload method
- Agent job fails → record failure, skip comparison, report it
- Python script fails → record failure, skip comparison, report it
- Table has no key columns → use full-row hash comparison

## Tools
- `pyodbc` / `sqlalchemy` for DB access
- `pandas` for snapshot + diff
- `subprocess` for running Python scripts
- `time` for polling job status

## Success Criteria
- Every destination table: IDENTICAL
- Every output file: IDENTICAL
- Zero value mismatches (after excluding known gotchas)
- Proof report saved with full evidence
