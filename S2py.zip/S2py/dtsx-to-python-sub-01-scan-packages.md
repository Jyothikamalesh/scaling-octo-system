# dtsx-to-python — Sub-Agent 01: Scan Packages

> Called by: `dtsx-to-python-orchestrator` → Stage 1: SCAN
> AI Required: ❌ Never

## Role
Find every .dtsx and .dtsconfig file in the source repo. Build an inventory with file paths, sizes, and which config belongs to which package.

## Mode
**Programmatic** — File system traversal + XML header parsing.

## Inputs
- Root directory path

## Outputs
`output/1-scan/manifest.json`

```json
{
  "timestamp": "ISO-8601",
  "packages": [
    {
      "name": "LoadCustomerData",
      "dtsx_path": "packages/LoadCustomerData.dtsx",
      "config_paths": ["configs/LoadCustomerData.dtsconfig"],
      "size_bytes": 45230,
      "last_modified": "2024-01-10",
      "child_packages": ["SharedLookups.dtsx"],
      "databases_referenced": ["CustomerDB", "StagingDB"],
      "files_referenced": ["//server/share/input.csv"]
    }
  ],
  "summary": {
    "total_packages": 12,
    "total_configs": 8,
    "orphan_configs": 0
  }
}
```

## Instructions

### Step 1: Find Files
```
SCAN root_directory recursively
COLLECT: *.dtsx, *.dtsconfig, *.dtproj, *.params, *.conmgr
RECORD: path, size, last_modified
```

### Step 2: Read Package Headers
```
FOR each .dtsx:
    PARSE XML — extract ONLY:
        - PackageName
        - CreationDate
        - Description
    DO NOT deep-parse (that's sub-02)
```

### Step 3: Match Configs to Packages
```
FOR each .dtsconfig:
    MATCH to package by: same base name, or dtproj references
    FLAG orphan configs with no matching package
```

### Step 4: Shallow Dependencies
```
FOR each .dtsx:
    SCAN for ConnectionManager nodes → database names
    SCAN for Execute Package Task → child package paths
    SCAN for file path strings → external file dependencies
```

### Step 5: Write Manifest
```
WRITE output/1-scan/manifest.json
```

## Error Handling
- Malformed XML → skip, log warning
- No config for a package → note as "unconfigured"
- Circular package refs → flag, don't fail

## Tools
- `lxml` or `xml.etree.ElementTree`
- `pathlib`
