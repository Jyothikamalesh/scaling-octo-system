# dtsx-to-python — Orchestrator

## Role
Coordinate the 1:1 SSIS-to-Python migration and **prove** the output is identical using real database comparisons.

## Mode
**Programmatic** — Delegates AI only for Script Tasks (sub-02 and sub-03).

---

## Sub-Agent Registry

```
┌─────┬──────────────────────────────────────────────┬──────────────┬──────────┐
│ #   │ Sub-Agent                                     │ AI Required  │ Stage    │
├─────┼──────────────────────────────────────────────┼──────────────┼──────────┤
│ 01  │ dtsx-to-python-sub-01-scan-packages           │ ❌ Never     │ SCAN     │
│ 02  │ dtsx-to-python-sub-02-parse-logic             │ 🟡 Rare      │ PARSE    │
│ 03  │ dtsx-to-python-sub-03-generate-code           │ 🟡 Rare      │ GENERATE │
│ 04  │ dtsx-to-python-sub-04-verify-coverage         │ ❌ Never     │ VERIFY   │
│ 05  │ dtsx-to-python-sub-05-capture-jobs            │ ❌ Never     │ JOBS     │
│ 06  │ dtsx-to-python-sub-06-prove-identical         │ ❌ Never     │ PROVE    │
│ 07  │ dtsx-to-python-sub-07-write-report            │ ❌ Never     │ REPORT   │
└─────┴──────────────────────────────────────────────┴──────────────┴──────────┘
```

---

## Pipeline

```
╔════════════════════════════════════════════════════════════════════════╗
║                   dtsx-to-python 1:1 MIGRATION                        ║
╠════════════════════════════════════════════════════════════════════════╣
║                                                                        ║
║  STAGE 1: SCAN                                                         ║
║  ┌───────────────────────────────────────────────┐                     ║
║  │  sub-01-scan-packages                          │  ❌ No AI          ║
║  │  Find all .dtsx/.dtsconfig files               │                    ║
║  └───────────────────────┬───────────────────────┘                     ║
║                          │                                             ║
║                          ▼                                             ║
║  STAGE 2: PARSE                                                        ║
║  ┌───────────────────────────────────────────────┐                     ║
║  │  sub-02-parse-logic                            │  🟡 Scripts only   ║
║  │  Extract exactly what each package does        │                    ║
║  └───────────────────────┬───────────────────────┘                     ║
║                          │                                             ║
║                          ▼                                             ║
║  ══════════════════════════════════════════════                         ║
║  ▶ CHECKPOINT: Human confirms analysis is accurate ◀                   ║
║  ══════════════════════════════════════════════                         ║
║                          │                                             ║
║                          ▼                                             ║
║  STAGE 3: GENERATE                                                     ║
║  ┌───────────────────────────────────────────────┐                     ║
║  │  sub-03-generate-code                          │  🟡 Scripts only   ║
║  │  1:1 Python. Same logic, same order.           │                    ║
║  └───────────────────────┬───────────────────────┘                     ║
║                          │                                             ║
║                          ▼                                             ║
║  STAGE 4: VERIFY                                                       ║
║  ┌───────────────────────────────────────────────┐                     ║
║  │  sub-04-verify-coverage                        │  ❌ No AI          ║
║  │  Diff: every SSIS component has Python code?   │                    ║
║  └───────────────────────┬───────────────────────┘                     ║
║        ▲                 │                                             ║
║        └── LOOP if ──────┘ (missing → back to sub-03, max 2)          ║
║                          │                                             ║
║                          ▼                                             ║
║  STAGE 5: CAPTURE JOBS                                                 ║
║  ┌───────────────────────────────────────────────┐                     ║
║  │  sub-05-capture-jobs                           │  ❌ No AI          ║
║  │  Extract SQL Agent jobs that trigger SSIS      │                    ║
║  │  Record schedules, steps, notifications        │                    ║
║  └───────────────────────┬───────────────────────┘                     ║
║                          │                                             ║
║                          ▼                                             ║
║  STAGE 6: PROVE                                                        ║
║  ┌───────────────────────────────────────────────┐                     ║
║  │  sub-06-prove-identical                        │  ❌ No AI          ║
║  │  THE PROOF:                                    │                    ║
║  │    1. Snapshot DB                              │                    ║
║  │    2. Run SSIS (via Agent job)                 │                    ║
║  │    3. Snapshot after SSIS                      │                    ║
║  │    4. Restore DB to before state               │                    ║
║  │    5. Run Python                               │                    ║
║  │    6. Snapshot after Python                    │                    ║
║  │    7. Diff: SSIS state vs Python state         │                    ║
║  │    8. Verdict: IDENTICAL or not                │                    ║
║  └───────────────────────┬───────────────────────┘                     ║
║                          │                                             ║
║                          ▼                                             ║
║  ══════════════════════════════════════════════                         ║
║  ▶ CHECKPOINT: Human reviews proof results ◀                           ║
║  ══════════════════════════════════════════════                         ║
║                          │                                             ║
║                          ▼                                             ║
║  STAGE 7: REPORT                                                       ║
║  ┌───────────────────────────────────────────────┐                     ║
║  │  sub-07-write-report                           │  ❌ No AI          ║
║  │  1:1 mapping table + proof results             │                    ║
║  └───────────────────────┬───────────────────────┘                     ║
║                          │                                             ║
║                          ▼                                             ║
║                       ✅ DONE                                           ║
╚════════════════════════════════════════════════════════════════════════╝
```

---

## Stage Config

### Stage 1: SCAN
```yaml
sub_agent: sub-01-scan-packages
needs_ai: false
blocking: true
on_failure: abort
```

### Stage 2: PARSE
```yaml
sub_agent: sub-02-parse-logic
needs_ai: partial (Script Tasks only)
blocking: true
checkpoint: HUMAN_REVIEW after
```

### Stage 3: GENERATE
```yaml
sub_agent: sub-03-generate-code
needs_ai: partial (Script Tasks only)
blocking: true
```

### Stage 4: VERIFY
```yaml
sub_agent: sub-04-verify-coverage
needs_ai: false
blocking: true
gate: 100% coverage required
on_fail: loop back to sub-03 (max 2)
```

### Stage 5: CAPTURE JOBS
```yaml
sub_agent: sub-05-capture-jobs
needs_ai: false
blocking: true
requires: database connection to msdb
```

### Stage 6: PROVE
```yaml
sub_agent: sub-06-prove-identical
needs_ai: false
blocking: false (report can generate even if proof not run)
requires: database connection, ability to trigger Agent jobs, DB snapshot/restore permissions
checkpoint: HUMAN_REVIEW after (review proof results)
```

### Stage 7: REPORT
```yaml
sub_agent: sub-07-write-report
needs_ai: false
```

---

## Recovery

```
HAPPY PATH:
  01 → 02 → 03 → 04 → 05 → 06 → 07 → ✅

COVERAGE GAP:
  01 → 02 → 03 → 04 FAIL → 03 (fix) → 04 PASS → 05 → 06 → 07

PROOF FAILS:
  06 shows differences → human investigates diffs in output/6-prove/diffs/
  → fix Python code → re-run 06

NO DB ACCESS FOR PROOF:
  01 → 02 → 03 → 04 → 05 → skip 06 → 07 (report notes "proof pending")
```

---

## CLI

```bash
# Full pipeline
python orchestrator.py --source ./ssis-packages/ --db "Server=prod-sql;Database=msdb;Trusted_Connection=yes" --mode full

# Skip proof (no DB access yet)
python orchestrator.py --source ./ssis-packages/ --mode full --skip-proof

# Run only the proof stage (code already generated)
python orchestrator.py --source ./ssis-packages/ --db "..." --stage 6

# Resume from stage 5
python orchestrator.py --source ./ssis-packages/ --db "..." --mode from:5
```
