"""
dtsx_to_python.py — Convert SSIS .dtsx packages to Python scripts. 1:1 mapping.

Usage:
    python dtsx_to_python.py LoadCustomerData.dtsx
    python dtsx_to_python.py LoadCustomerData.dtsx --config LoadCustomerData.dtsconfig
    python dtsx_to_python.py ./packages/              # converts all .dtsx in a folder
    python dtsx_to_python.py ./packages/ --outdir ./python_output/

No AI. No agents. Just XML parsing + code templates.
"""

import argparse
import json
import re
import sys
import textwrap
from pathlib import Path
from datetime import datetime
import xml.etree.ElementTree as ET


# ═════════════════════════════════════════════════════════════════════
# SSIS EXPRESSION → PYTHON EXPRESSION TRANSLATOR
# This is the complete mapping. SSIS has ~30 expression functions.
# ═════════════════════════════════════════════════════════════════════

EXPR_FUNCTIONS = {
    # Date/time
    "GETDATE()":                "datetime.now()",
    "GETUTCDATE()":             "datetime.utcnow()",
    # String
    "UPPER":                    ".upper()",
    "LOWER":                    ".lower()",
    "TRIM":                     ".strip()",
    "LTRIM":                    ".lstrip()",
    "RTRIM":                    ".rstrip()",
    "LEN":                      "len",
    "REPLACE":                  "replace",
    "REVERSE":                  "[::-1]",
    # Null
    "ISNULL":                   "pd.isna",
    # Cast
    "(DT_STR":                  "str",
    "(DT_WSTR":                 "str",
    "(DT_I4)":                  "int",
    "(DT_I8)":                  "int",
    "(DT_R4)":                  "float",
    "(DT_R8)":                  "float",
    "(DT_BOOL)":                "bool",
    "(DT_DBDATE)":              "pd.to_datetime",
    "(DT_DBTIMESTAMP)":         "pd.to_datetime",
    "(DT_DBTIMESTAMP2)":        "pd.to_datetime",
}


def translate_ssis_expression(expr: str) -> str:
    """Translate an SSIS expression to Python. Best-effort, flags unknowns."""
    if not expr:
        return "None"

    result = expr

    # GETDATE()
    result = result.replace("GETDATE()", "datetime.now()")
    result = result.replace("GETUTCDATE()", "datetime.utcnow()")

    # Variable references: @[User::VarName] → User_VarName
    result = re.sub(r'@\[User::(\w+)\]', r'User_\1', result)
    result = re.sub(r'@\[System::(\w+)\]', r'System_\1', result)
    result = result.replace("@[System::StartTime]", "datetime.now()")

    # DATEADD("unit", count, date) → date + timedelta(unit=count)
    dateadd = re.search(r'DATEADD\("(\w+)",\s*(-?\d+),\s*(.+?)\)', result)
    if dateadd:
        unit_map = {"dd": "days", "d": "days", "mm": "days", "hh": "hours",
                     "mi": "minutes", "ss": "seconds", "yy": "days"}
        unit = unit_map.get(dateadd.group(1), "days")
        count = dateadd.group(2)
        base = translate_ssis_expression(dateadd.group(3))
        multiplier = 365 if dateadd.group(1) in ("yy", "yyyy") else 30 if dateadd.group(1) == "mm" else 1
        actual_count = int(count) * multiplier
        result = f"{base} + timedelta({unit}={actual_count})"

    # SUBSTRING(@var, start, len) → var[start-1:start-1+len]  (SSIS is 1-based)
    substr = re.search(r'SUBSTRING\((.+?),\s*(\d+),\s*(\d+)\)', result)
    if substr:
        var = translate_ssis_expression(substr.group(1))
        start = int(substr.group(2)) - 1
        length = int(substr.group(3))
        result = f"{var}[{start}:{start + length}]"

    # REPLACE(str, old, new) → str.replace(old, new)
    repl = re.search(r'REPLACE\((.+?),\s*"(.+?)",\s*"(.+?)"\)', result)
    if repl:
        var = translate_ssis_expression(repl.group(1))
        result = f'{var}.replace("{repl.group(2)}", "{repl.group(3)}")'

    # LEN(x) → len(x)
    result = re.sub(r'LEN\((.+?)\)', r'len(\1)', result)

    # UPPER/LOWER/TRIM
    result = re.sub(r'UPPER\((.+?)\)', r'\1.upper()', result)
    result = re.sub(r'LOWER\((.+?)\)', r'\1.lower()', result)
    result = re.sub(r'TRIM\((.+?)\)', r'\1.strip()', result)
    result = re.sub(r'LTRIM\((.+?)\)', r'\1.lstrip()', result)
    result = re.sub(r'RTRIM\((.+?)\)', r'\1.rstrip()', result)

    # ISNULL(x) → pd.isna(x)
    result = re.sub(r'ISNULL\((.+?)\)', r'pd.isna(\1)', result)

    # Ternary: expr ? a : b → a if expr else b
    ternary = re.search(r'(.+?)\s*\?\s*(.+?)\s*:\s*(.+)', result)
    if ternary:
        result = f"{ternary.group(2)} if {ternary.group(1)} else {ternary.group(3)}"

    # Casts: (DT_STR, length, codepage)@var → str(var)
    result = re.sub(r'\(DT_(?:W?STR),\s*\d+,\s*\d+\)', 'str', result)
    result = re.sub(r'\(DT_I[48]\)', 'int', result)
    result = re.sub(r'\(DT_R[48]\)', 'float', result)
    result = re.sub(r'\(DT_DB(?:DATE|TIMESTAMP\d?)\)', 'pd.to_datetime', result)
    result = re.sub(r'\(DT_BOOL\)', 'bool', result)

    # Operators: == stays, || → or, && → and, ! → not
    result = result.replace("||", " or ").replace("&&", " and ")

    # String concat: + stays the same in Python
    # NULL literal
    result = result.replace("NULL", "None")

    return result


# ═════════════════════════════════════════════════════════════════════
# XML PARSING HELPERS
# ═════════════════════════════════════════════════════════════════════

def attr(elem, local_name, default=None):
    """Get attribute handling DTS namespace."""
    for k, v in elem.attrib.items():
        if k.endswith(f"}}{local_name}") or k == local_name:
            return v
    return default


def prop(elem, prop_name, default=None):
    """Get a DTS property from child elements."""
    for child in elem:
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
        name = attr(child, "Name", "")
        if name == prop_name:
            return child.text or attr(child, "Value", default)
    return default


def sanitize(name: str) -> str:
    """SSIS name → valid Python identifier."""
    s = name.replace("::", "_").replace(" ", "_").replace("-", "_")
    s = "".join(c if c.isalnum() or c == "_" else "_" for c in s)
    return f"_{s}" if s and s[0].isdigit() else s


def tag_local(elem) -> str:
    """Get local tag name without namespace."""
    return elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag


# ═════════════════════════════════════════════════════════════════════
# TASK TYPE IDENTIFICATION
# ═════════════════════════════════════════════════════════════════════

TASK_TYPES = {
    "ExecuteSQLTask": "ExecuteSQLTask",
    "Pipeline": "DataFlowTask",
    "ScriptTask": "ScriptTask",
    "ExecutePackageTask": "ExecutePackageTask",
    "FileSystemTask": "FileSystemTask",
    "SendMailTask": "SendMailTask",
    "FtpTask": "FTPTask",
    "FORLOOP": "ForLoop",
    "FOREACHLOOP": "ForeachLoop",
    "SEQUENCE": "Sequence",
}


def identify_type(elem) -> str:
    creation = attr(elem, "CreationName", "")
    for pattern, ttype in TASK_TYPES.items():
        if pattern.lower() in creation.lower():
            return ttype
    return f"Unknown_{creation}"


# ═════════════════════════════════════════════════════════════════════
# PARSE .DTSCONFIG
# ═════════════════════════════════════════════════════════════════════

def parse_dtsconfig(path: Path) -> dict:
    """Returns {ConnectionManagerName: ConnectionString}."""
    overrides = {}
    if not path or not path.exists():
        return overrides
    try:
        for elem in ET.parse(path).iter():
            if tag_local(elem) == "Configuration":
                config_path = elem.attrib.get("Path", "")
                match = re.search(r'Connections\[(\w+)\].*ConnectionString', config_path)
                if match:
                    for child in elem:
                        if tag_local(child) == "ConfiguredValue" and child.text:
                            overrides[match.group(1)] = child.text
    except ET.ParseError:
        pass
    return overrides


# ═════════════════════════════════════════════════════════════════════
# MAIN PARSER: .dtsx → structured dict
# ═════════════════════════════════════════════════════════════════════

def parse_dtsx(dtsx_path: Path, config_overrides: dict) -> dict:
    """Parse a .dtsx file into a structured dict of everything it does."""
    tree = ET.parse(dtsx_path)
    root = tree.getroot()

    pkg = {
        "name": attr(root, "ObjectName", dtsx_path.stem),
        "connections": [],
        "variables": [],
        "tasks": [],
        "data_flows": [],
        "precedence": [],
        "event_handlers": [],
        "script_tasks": [],
    }

    # ── Connections ──
    for cm in root.iter():
        if tag_local(cm) != "ConnectionManager":
            continue
        name = attr(cm, "ObjectName", "")
        if not name:
            continue
        creation = attr(cm, "CreationName", "")
        cs = prop(cm, "ConnectionString", "")
        if name in config_overrides:
            cs = config_overrides[name]

        conn_type = "OLEDB"
        cl = creation.lower()
        if "flatfile" in cl or "flat file" in cl:
            conn_type = "FlatFile"
        elif "excel" in cl:
            conn_type = "Excel"
        elif "smtp" in cl:
            conn_type = "SMTP"
        elif "ftp" in cl:
            conn_type = "FTP"
        elif "ado" in cl:
            conn_type = "ADO.NET"
        elif "file" in cl:
            conn_type = "File"

        pkg["connections"].append({"name": name, "type": conn_type, "connection_string": cs})

    # ── Variables ──
    for var in root.iter():
        if tag_local(var) != "Variable":
            continue
        ns = attr(var, "Namespace", "User")
        if ns == "System":
            continue
        name = attr(var, "ObjectName", "")
        if not name:
            continue
        dtype = attr(var, "DataType", "String")
        expr = attr(var, "Expression", "")
        val = None
        for child in var:
            if tag_local(child) == "VariableValue":
                val = child.text
        pkg["variables"].append({
            "name": f"{ns}__{name}",
            "type": dtype,
            "value": val,
            "expression": expr or None,
        })

    # ── Tasks (control flow) ──
    counter = [0]

    def parse_tasks(parent, depth=0):
        for child in parent:
            tl = tag_local(child)
            if tl == "Executables":
                parse_tasks(child, depth)
                continue
            if tl != "Executable":
                continue

            counter[0] += 1
            ttype = identify_type(child)
            tname = attr(child, "ObjectName", f"Task_{counter[0]}")
            dts_id = attr(child, "DTSID", "")

            task = {"id": counter[0], "type": ttype, "name": tname, "dts_id": dts_id}

            if ttype == "ExecuteSQLTask":
                task["sql"] = prop(child, "SqlStatementSource", "")
                task["connection"] = prop(child, "Connection", "")

            elif ttype == "ScriptTask":
                task["language"] = prop(child, "ScriptLanguage", "CSharp")
                code = ""
                for sc in child.iter():
                    if tag_local(sc) in ("ScriptProject",) and sc.text and len(sc.text) > 20:
                        code = sc.text[:5000]
                task["code"] = code
                pkg["script_tasks"].append(task)

            elif ttype == "ExecutePackageTask":
                task["child_package"] = prop(child, "PackageName", "")

            elif ttype == "FileSystemTask":
                task["operation"] = prop(child, "Operation", "")
                task["source"] = prop(child, "Source", "")
                task["destination"] = prop(child, "Destination", "")

            elif ttype == "SendMailTask":
                task["to"] = prop(child, "ToLine", "")
                task["subject"] = prop(child, "Subject", "")
                task["body"] = prop(child, "MessageSource", "")

            elif ttype == "DataFlowTask":
                # Parse the pipeline components
                df_components = []
                for pipeline in child.iter():
                    if tag_local(pipeline) not in ("pipeline", "Pipeline"):
                        continue
                    for comp in pipeline.iter():
                        if tag_local(comp) != "component":
                            continue
                        c = {
                            "name": comp.attrib.get("name", ""),
                            "class": comp.attrib.get("componentClassID", ""),
                            "properties": {},
                            "output_columns": [],
                            "input_columns": [],
                        }
                        for p in comp.iter():
                            if tag_local(p) == "property" and p.attrib.get("name") and p.text:
                                c["properties"][p.attrib["name"]] = p.text
                            elif tag_local(p) == "outputColumn":
                                c["output_columns"].append({
                                    "name": p.attrib.get("name", ""),
                                    "expression": p.attrib.get("expression"),
                                    "dataType": p.attrib.get("dataType", ""),
                                })
                            elif tag_local(p) == "inputColumn":
                                c["input_columns"].append({
                                    "name": p.attrib.get("cachedName", ""),
                                    "dataType": p.attrib.get("cachedDataType", ""),
                                })
                        if c["name"]:
                            df_components.append(c)

                task["components"] = df_components
                pkg["data_flows"].append(task)

            elif ttype in ("ForLoop", "ForeachLoop", "Sequence"):
                parse_tasks(child, depth + 1)

            pkg["tasks"].append(task)

    parse_tasks(root)

    # ── Precedence constraints ──
    for pc in root.iter():
        if tag_local(pc) != "PrecedenceConstraint":
            continue
        pkg["precedence"].append({
            "from": attr(pc, "From", ""),
            "to": attr(pc, "To", ""),
            "value": attr(pc, "Value", "Success"),
            "expression": attr(pc, "Expression"),
        })

    # ── Event handlers ──
    for eh in root.iter():
        if tag_local(eh) != "EventHandler":
            continue
        event = attr(eh, "EventName", "")
        if event:
            handler = {"event": event, "tasks": []}
            for child in eh.iter():
                if tag_local(child) == "Executable":
                    ht = identify_type(child)
                    hn = attr(child, "ObjectName", "")
                    h = {"type": ht, "name": hn}
                    if ht == "SendMailTask":
                        h["to"] = prop(child, "ToLine", "")
                        h["subject"] = prop(child, "Subject", "")
                    handler["tasks"].append(h)
            pkg["event_handlers"].append(handler)

    return pkg


# ═════════════════════════════════════════════════════════════════════
# CODE GENERATOR: structured dict → .py file
# ═════════════════════════════════════════════════════════════════════

def classify_component(class_id: str) -> str:
    """Classify a data flow component as source/transform/destination."""
    cl = class_id.lower()
    if "source" in cl:
        return "source"
    elif "destination" in cl:
        return "destination"
    else:
        return "transform"


def component_transform_type(class_id: str) -> str:
    """Get the specific transform type."""
    mapping = {
        "derivedcolumn": "DerivedColumn",
        "lookup": "Lookup",
        "conditionalsplit": "ConditionalSplit",
        "sort": "Sort",
        "aggregate": "Aggregate",
        "unionall": "UnionAll",
        "multicast": "Multicast",
        "dataconvert": "DataConversion",
        "rowcount": "RowCount",
        "oledbcommand": "OLEDBCommand",
        "mergejoin": "MergeJoin",
        "merge": "Merge",
        "pivot": "Pivot",
        "unpivot": "Unpivot",
    }
    cl = class_id.lower()
    for k, v in mapping.items():
        if k in cl:
            return v
    return "Unknown"


def generate_python(pkg: dict) -> str:
    """Generate complete .py file from parsed package."""
    L = []  # lines

    # ── Header ──
    L.append(f'"""\n1:1 migration of {pkg["name"]}.dtsx\nGenerated: {datetime.now().isoformat()}\n"""')
    L.append("")
    L.append("import pandas as pd")
    L.append("from sqlalchemy import create_engine, text")
    L.append("from datetime import datetime, timedelta")
    L.append("import logging")
    L.append("import os")
    L.append("")
    L.append(f'logger = logging.getLogger("{pkg["name"]}")')
    L.append("")

    # ── Config ──
    L.append(f"# {'='*60}")
    L.append(f"# CONFIG — loaded from .dtsconfig at runtime, not hardcoded")
    L.append(f"# Deploy tool writes .dtsconfig → this script reads it")
    L.append(f"#")
    L.append(f"# Resolution order:")
    L.append(f"#   1. --config CLI flag")
    L.append(f"#   2. {pkg['name']}.dtsconfig next to this script")
    L.append(f"#   3. SSIS_CONN_* environment variables")
    L.append(f"# {'='*60}")
    L.append(f"from dtsconfig_reader import load as load_config, get_engine, get_variable")
    L.append(f"")
    L.append(f'CONFIG = load_config(package_name="{pkg["name"]}")')
    L.append(f"")
    L.append(f"# Connections available in .dtsconfig:")
    for conn in pkg["connections"]:
        L.append(f'#   {conn["name"]} ({conn["type"]})')
    L.append("")

    # ── Variables ──
    L.append(f"# {'='*60}")
    L.append(f"# VARIABLES")
    L.append(f"# {'='*60}")
    for var in pkg["variables"]:
        py_name = sanitize(var["name"])
        if var["expression"]:
            py_val = translate_ssis_expression(var["expression"])
            L.append(f"{py_name} = {py_val}  # expression: {var['expression']}")
        elif var["type"] in ("3", "Int32", "System.Int32"):
            L.append(f"{py_name} = {var['value'] or 0}")
        elif var["type"] in ("11", "Boolean", "System.Boolean"):
            L.append(f"{py_name} = {str(var['value']).capitalize() if var['value'] else 'True'}")
        elif var["type"] in ("7", "DateTime", "System.DateTime"):
            L.append(f"{py_name} = datetime.now()")
        else:
            L.append(f'{py_name} = {repr(var["value"])}')
    L.append("")

    # ── Task functions ──
    L.append(f"# {'='*60}")
    L.append(f"# TASKS")
    L.append(f"# {'='*60}")

    for task in pkg["tasks"]:
        fname = f"task_{task['id']}_{sanitize(task['name'])}"
        L.append("")

        if task["type"] == "ExecuteSQLTask":
            sql = task.get("sql", "").replace('"""', "'''")
            conn = task.get("connection", "")
            L.append(f"def {fname}():")
            L.append(f'    """SSIS: ExecuteSQLTask — {task["name"]}"""')
            L.append(f'    engine = get_engine(CONFIG, "{conn}")')
            L.append(f"    with engine.connect() as conn:")
            L.append(f'        conn.execute(text("""{sql}"""))')
            L.append(f"        conn.commit()")

        elif task["type"] == "DataFlowTask":
            L.append(f"def {fname}():")
            L.append(f'    """SSIS: DataFlowTask — {task["name"]}"""')

            components = task.get("components", [])
            sources = [c for c in components if classify_component(c["class"]) == "source"]
            transforms = [c for c in components if classify_component(c["class"]) == "transform"]
            destinations = [c for c in components if classify_component(c["class"]) == "destination"]

            # Source
            for src in sources:
                sql = src["properties"].get("SqlCommand", "")
                table = src["properties"].get("OpenRowset", "")
                conn = src["properties"].get("ConnectionManager", "")
                L.append(f"")
                L.append(f"    # SOURCE: {src['name']}")
                if sql:
                    L.append(f'    engine_src = get_engine(CONFIG, "{conn}")')
                    L.append(f'    df = pd.read_sql("""{sql.replace(chr(34)*3, chr(39)*3)}""", engine_src)')
                elif table:
                    L.append(f'    engine_src = get_engine(CONFIG, "{conn}")')
                    L.append(f'    df = pd.read_sql("SELECT * FROM {table}", engine_src)')
                elif "flatfile" in src["class"].lower() or "csv" in src["class"].lower():
                    L.append(f'    df = pd.read_csv(CONFIG["connections"]["{conn}"])')
                else:
                    L.append(f"    df = pd.DataFrame()  # SOURCE TYPE: {src['class']}")

            # Transforms
            for tr in transforms:
                ttype = component_transform_type(tr["class"])
                L.append(f"")
                L.append(f"    # TRANSFORM: {tr['name']} ({ttype})")

                if ttype == "DerivedColumn":
                    for col in tr.get("output_columns", []):
                        expr = translate_ssis_expression(col.get("expression", ""))
                        L.append(f'    df["{col["name"]}"] = {expr}')

                elif ttype == "Lookup":
                    sql = tr["properties"].get("SqlCommand", "")
                    conn = tr["properties"].get("ConnectionManager", "")
                    join_cols = [c["name"] for c in tr.get("input_columns", []) if c["name"]]
                    L.append(f'    lookup_engine = get_engine(CONFIG, "{conn}")')
                    if sql:
                        L.append(f'    lookup_df = pd.read_sql("""{sql}""", lookup_engine)')
                    else:
                        L.append(f'    lookup_df = pd.DataFrame()  # lookup SQL not extracted')
                    if join_cols:
                        L.append(f'    df = df.merge(lookup_df, on={join_cols}, how="left")')
                    else:
                        L.append(f'    # df = df.merge(lookup_df, on=[KEY_COLUMNS], how="left")')
                    if tr.get("output_columns"):
                        oc = tr["output_columns"][0]["name"]
                        L.append(f'    error_rows = df[df["{oc}"].isna()].copy()')
                        L.append(f'    df = df[df["{oc}"].notna()].copy()')

                elif ttype == "ConditionalSplit":
                    for col in tr.get("output_columns", []):
                        if col.get("expression"):
                            py_expr = translate_ssis_expression(col["expression"])
                            L.append(f'    {sanitize(col["name"])}_df = df[{py_expr}].copy()')
                        elif col["name"]:
                            L.append(f'    {sanitize(col["name"])}_df = df.copy()  # default output')

                elif ttype == "Sort":
                    cols = [c["name"] for c in tr.get("input_columns", []) if c["name"]]
                    L.append(f'    df = df.sort_values({cols})')

                elif ttype == "Aggregate":
                    L.append(f'    # df = df.groupby([...]).agg({{...}}).reset_index()')
                    L.append(f'    pass  # check analysis for group-by columns')

                elif ttype == "UnionAll":
                    L.append(f'    # df = pd.concat([input1, input2], ignore_index=True)')
                    L.append(f'    pass')

                elif ttype == "DataConversion":
                    for col in tr.get("output_columns", []):
                        L.append(f'    df["{col["name"]}"] = df["{col["name"]}"].astype(str)')

                elif ttype == "RowCount":
                    L.append(f'    row_count = len(df)')

                elif ttype == "OLEDBCommand":
                    sql = tr["properties"].get("SqlCommand", "")
                    L.append(f'    # WARNING: row-by-row execution')
                    L.append(f'    engine_cmd = get_engine(CONFIG, "...")')
                    L.append(f'    for _, row in df.iterrows():')
                    L.append(f'        engine_cmd.execute(text("""{sql}"""), dict(row))')

                else:
                    L.append(f'    pass  # {ttype} — manual translation needed')

            # Destinations
            for dest in destinations:
                table = dest["properties"].get("OpenRowset", "")
                conn = dest["properties"].get("ConnectionManager", "")
                L.append(f"")
                L.append(f"    # DESTINATION: {dest['name']}")

                if "oledb" in dest["class"].lower() or "ado" in dest["class"].lower():
                    schema, tname = "", table
                    clean = table.replace("[", "").replace("]", "")
                    if "." in clean:
                        parts = clean.split(".", 1)
                        schema, tname = parts[0], parts[1]
                    L.append(f'    engine_dst = get_engine(CONFIG, "{conn}")')
                    if schema:
                        L.append(f'    df.to_sql("{tname}", engine_dst, schema="{schema}", if_exists="append", index=False)')
                    else:
                        L.append(f'    df.to_sql("{tname}", engine_dst, if_exists="append", index=False)')

                elif "flatfile" in dest["class"].lower():
                    L.append(f'    df.to_csv(CONFIG["connections"]["{conn}"], index=False)')

                elif "excel" in dest["class"].lower():
                    L.append(f'    df.to_excel(CONFIG["connections"]["{conn}"], index=False)')

                else:
                    L.append(f'    # destination type: {dest["class"]}')

            L.append(f"    return len(df)")

        elif task["type"] == "ScriptTask":
            L.append(f"def {fname}():")
            L.append(f'    """SSIS: ScriptTask — {task["name"]}')
            L.append(f'    Language: {task.get("language", "C#")}')
            L.append(f'    *** NEEDS MANUAL TRANSLATION ***')
            L.append(f'    """')
            if task.get("code"):
                for line in task["code"].split("\n")[:15]:
                    L.append(f"    # {line.rstrip()}")
            L.append(f'    raise NotImplementedError("ScriptTask: {task["name"]}")')

        elif task["type"] == "ExecutePackageTask":
            child = sanitize(task.get("child_package", "").replace(".dtsx", ""))
            L.append(f"def {fname}():")
            L.append(f'    """SSIS: ExecutePackageTask — {task["name"]}"""')
            L.append(f"    from {child} import main as run_child")
            L.append(f"    run_child()")

        elif task["type"] == "FileSystemTask":
            L.append(f"def {fname}():")
            L.append(f'    """SSIS: FileSystemTask — {task["name"]}"""')
            L.append(f"    import shutil")
            op = task.get("operation", "").lower()
            src = task.get("source", "")
            dst = task.get("destination", "")
            if "move" in op or "rename" in op:
                L.append(f'    shutil.move(r"{src}", r"{dst}")')
            elif "delete" in op:
                L.append(f'    os.remove(r"{src}")')
            else:
                L.append(f'    shutil.copy2(r"{src}", r"{dst}")')

        elif task["type"] == "SendMailTask":
            L.append(f"def {fname}():")
            L.append(f'    """SSIS: SendMailTask — {task["name"]}"""')
            L.append(f"    import smtplib")
            L.append(f"    from email.mime.text import MIMEText")
            L.append(f'    msg = MIMEText("""{task.get("body", "")}""")')
            L.append(f'    msg["Subject"] = "{task.get("subject", "")}"')
            L.append(f'    msg["To"] = "{task.get("to", "")}"')

        else:
            L.append(f"def {fname}():")
            L.append(f'    """SSIS: {task["type"]} — {task["name"]}"""')
            L.append(f"    pass  # {task['type']}")

    # ── Main ──
    L.append("")
    L.append(f"# {'='*60}")
    L.append(f"# MAIN — SSIS execution order")
    L.append(f"# {'='*60}")

    has_error_handler = any(eh["event"] == "OnError" for eh in pkg["event_handlers"])
    error_mail = None
    for eh in pkg["event_handlers"]:
        for t in eh.get("tasks", []):
            if t["type"] == "SendMailTask":
                error_mail = t

    L.append("def main():")
    L.append(f'    """SSIS Package: {pkg["name"]}"""')

    if has_error_handler:
        L.append("    try:")
        indent = "        "
    else:
        indent = "    "

    # Build dts_id → task_id map for precedence constraint resolution
    id_map = {t["dts_id"]: t for t in pkg["tasks"] if t.get("dts_id")}

    for task in pkg["tasks"]:
        fname = f"task_{task['id']}_{sanitize(task['name'])}"

        # Check if this task has an expression-based precedence constraint
        for pc in pkg["precedence"]:
            if pc["to"] == task.get("dts_id") and pc.get("expression"):
                py_expr = translate_ssis_expression(pc["expression"])
                L.append(f"{indent}if {py_expr}:  # precedence expression")
                L.append(f"{indent}    {fname}()")
                break
        else:
            L.append(f"{indent}{fname}()")

    if has_error_handler:
        L.append("    except Exception as e:")
        L.append('        logger.error(f"Package failed: {e}")')
        if error_mail:
            L.append(f'        # OnError: email to {error_mail.get("to", "?")}')
            L.append(f'        # Subject: {error_mail.get("subject", "?")}')
        L.append("        raise")

    L.append("")
    L.append("")
    L.append('if __name__ == "__main__":')
    L.append("    logging.basicConfig(level=logging.INFO)")
    L.append("    main()")

    return "\n".join(L)


# ═════════════════════════════════════════════════════════════════════
# CLI
# ═════════════════════════════════════════════════════════════════════

def convert_one(dtsx_path: Path, config_path: Path = None, outdir: Path = None) -> Path:
    """Convert a single .dtsx file to .py."""
    # Find config
    config_overrides = {}
    if config_path and config_path.exists():
        config_overrides = parse_dtsconfig(config_path)
    else:
        # Try same-name .dtsconfig
        auto_config = dtsx_path.with_suffix(".dtsconfig")
        if auto_config.exists():
            config_overrides = parse_dtsconfig(auto_config)

    # Parse
    pkg = parse_dtsx(dtsx_path, config_overrides)

    # Generate
    code = generate_python(pkg)

    # Write
    out = (outdir or dtsx_path.parent) / f"{dtsx_path.stem}.py"
    out.write_text(code, encoding="utf-8")

    # Verify syntax
    import py_compile
    try:
        py_compile.compile(str(out), doraise=True)
        status = "✅"
    except py_compile.PyCompileError as e:
        status = f"⚠️ syntax error: {e}"

    tasks = len(pkg["tasks"])
    scripts = len(pkg["script_tasks"])
    script_warn = f" ({scripts} ScriptTasks need manual work)" if scripts else ""
    print(f"  {status} {dtsx_path.name} → {out.name} ({tasks} tasks{script_warn})")

    return out


def main():
    parser = argparse.ArgumentParser(description="Convert SSIS .dtsx to Python. 1:1 mapping.")
    parser.add_argument("input", help="Path to .dtsx file or directory of .dtsx files")
    parser.add_argument("--config", help="Path to .dtsconfig file (auto-detected if same name)")
    parser.add_argument("--outdir", help="Output directory (default: same as input)")
    args = parser.parse_args()

    input_path = Path(args.input)
    outdir = Path(args.outdir) if args.outdir else None
    if outdir:
        outdir.mkdir(parents=True, exist_ok=True)

    if input_path.is_file():
        config = Path(args.config) if args.config else None
        convert_one(input_path, config, outdir)
    elif input_path.is_dir():
        dtsx_files = sorted(input_path.rglob("*.dtsx"))
        if not dtsx_files:
            print(f"No .dtsx files found in {input_path}")
            sys.exit(1)
        print(f"Found {len(dtsx_files)} .dtsx files\n")
        for f in dtsx_files:
            convert_one(f, outdir=outdir)
    else:
        print(f"Not found: {input_path}")
        sys.exit(1)


if __name__ == "__main__":
    main()
