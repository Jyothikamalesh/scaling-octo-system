"""
prove_identical.py — Verify SSIS and Python produce the exact same database state.

Usage:
    python prove_identical.py --db "Server=prod-sql;Database=msdb;Trusted_Connection=yes" \
                              --job "ETL_Load_Customer_Data" \
                              --script LoadCustomerData.py \
                              --tables "stg.Customers_US,stg.Customers_EU" \
                              --keys "CustID"

    python prove_identical.py --db "..." --job "..." --script ... --tables ... --keys ... --exclude-cols "LoadDate"

Steps:
    1. Snapshot destination tables
    2. Run SSIS via SQL Agent job
    3. Snapshot after SSIS
    4. Restore tables to original state
    5. Run Python script
    6. Snapshot after Python
    7. Diff the two after-states
    8. Print verdict: IDENTICAL or MISMATCH with details
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime

import pandas as pd
from sqlalchemy import create_engine, text


def snapshot_table(engine, table: str) -> pd.DataFrame:
    """Read entire table into DataFrame."""
    return pd.read_sql(f"SELECT * FROM {table}", engine)


def trigger_job(engine, job_name: str, timeout_min: int = 30) -> dict:
    """Start SQL Agent job and wait for completion."""
    print(f"  Starting job: {job_name}")
    with engine.connect() as conn:
        conn.execute(text(f"EXEC msdb.dbo.sp_start_job @job_name = N'{job_name}'"))
        conn.commit()

    start = time.time()
    while time.time() - start < timeout_min * 60:
        time.sleep(5)
        try:
            with engine.connect() as conn:
                # Check latest job history
                row = conn.execute(text("""
                    SELECT TOP 1 run_status, run_duration
                    FROM msdb.dbo.sysjobhistory
                    WHERE job_id = (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = :name)
                    AND step_id = 0
                    ORDER BY instance_id DESC
                """), {"name": job_name}).fetchone()

                if row and row[0] in (0, 1):
                    elapsed = round(time.time() - start, 1)
                    status = "success" if row[0] == 1 else "failed"
                    print(f"  Job {status} in {elapsed}s")
                    return {"status": status, "elapsed": elapsed}
        except Exception:
            pass

    return {"status": "timeout"}


def restore_tables(engine, tables: list, before_snapshots: dict):
    """Restore tables to their before-state by truncating and reinserting."""
    print("  Restoring tables to before state...")
    for table in tables:
        df = before_snapshots[table]
        with engine.connect() as conn:
            conn.execute(text(f"DELETE FROM {table}"))
            conn.commit()
        if len(df) > 0:
            schema, tname = None, table
            clean = table.replace("[", "").replace("]", "")
            if "." in clean:
                parts = clean.split(".", 1)
                schema, tname = parts[0], parts[1]
            if schema:
                df.to_sql(tname, engine, schema=schema, if_exists="append", index=False)
            else:
                df.to_sql(tname, engine, if_exists="append", index=False)
        print(f"    {table}: restored {len(df)} rows")


def diff_dataframes(ssis_df: pd.DataFrame, python_df: pd.DataFrame,
                    key_cols: list, exclude_cols: list) -> dict:
    """Compare two DataFrames row-by-row."""
    # Drop excluded columns
    for col in exclude_cols:
        if col in ssis_df.columns:
            ssis_df = ssis_df.drop(columns=[col])
        if col in python_df.columns:
            python_df = python_df.drop(columns=[col])

    result = {
        "ssis_rows": len(ssis_df),
        "python_rows": len(python_df),
        "row_count_match": len(ssis_df) == len(python_df),
        "columns_match": sorted(ssis_df.columns.tolist()) == sorted(python_df.columns.tolist()),
    }

    # Normalize and sort for comparison
    ssis_n = ssis_df.fillna("").astype(str)
    python_n = python_df.fillna("").astype(str)

    sort_cols = [c for c in key_cols if c in ssis_n.columns] or list(ssis_n.columns)[:2]
    ssis_n = ssis_n.sort_values(sort_cols).reset_index(drop=True)
    python_n = python_n.sort_values(sort_cols).reset_index(drop=True)

    if ssis_n.equals(python_n):
        result["identical"] = True
        result["diffs"] = []
    else:
        result["identical"] = False
        diffs = []
        common_cols = [c for c in ssis_n.columns if c in python_n.columns]
        for col in common_cols:
            if col in sort_cols:
                continue
            mask = ssis_n[col] != python_n[col]
            n = mask.sum()
            if n > 0:
                samples = []
                for idx in mask[mask].index[:5]:
                    samples.append({
                        "row": int(idx),
                        "ssis": ssis_n.loc[idx, col],
                        "python": python_n.loc[idx, col],
                    })
                diffs.append({"column": col, "count": int(n), "samples": samples})
        result["diffs"] = diffs

    return result


def main():
    parser = argparse.ArgumentParser(description="Prove SSIS and Python produce identical output.")
    parser.add_argument("--db", required=True, help="ODBC connection string")
    parser.add_argument("--job", required=True, help="SQL Agent job name")
    parser.add_argument("--script", required=True, help="Python script to run")
    parser.add_argument("--tables", required=True, help="Comma-separated destination tables")
    parser.add_argument("--keys", default="", help="Comma-separated key columns for diff alignment")
    parser.add_argument("--exclude-cols", default="", help="Comma-separated columns to exclude (e.g. LoadDate)")
    parser.add_argument("--timeout", type=int, default=30, help="Job timeout in minutes")
    args = parser.parse_args()

    tables = [t.strip() for t in args.tables.split(",") if t.strip()]
    key_cols = [k.strip() for k in args.keys.split(",") if k.strip()]
    exclude_cols = [c.strip() for c in args.exclude_cols.split(",") if c.strip()]

    engine = create_engine(f"mssql+pyodbc:///?odbc_connect={args.db}")

    print("=" * 60)
    print("  PROOF: SSIS vs Python")
    print("=" * 60)

    # Step 1: Snapshot BEFORE
    print("\n[1/7] Snapshot BEFORE")
    before = {}
    for t in tables:
        before[t] = snapshot_table(engine, t)
        print(f"  {t}: {len(before[t])} rows")

    # Step 2: Run SSIS
    print(f"\n[2/7] Run SSIS job: {args.job}")
    ssis_result = trigger_job(engine, args.job, args.timeout)
    if ssis_result["status"] != "success":
        print(f"  SSIS job {ssis_result['status']}. Aborting.")
        sys.exit(1)

    # Step 3: Snapshot AFTER SSIS
    print("\n[3/7] Snapshot AFTER SSIS")
    after_ssis = {}
    for t in tables:
        after_ssis[t] = snapshot_table(engine, t)
        print(f"  {t}: {len(after_ssis[t])} rows")

    # Step 4: Restore
    print("\n[4/7] Restore to BEFORE state")
    restore_tables(engine, tables, before)

    # Step 5: Run Python
    print(f"\n[5/7] Run Python: {args.script}")
    result = subprocess.run(
        [sys.executable, args.script],
        capture_output=True, text=True, timeout=args.timeout * 60
    )
    if result.returncode != 0:
        print(f"  Python script failed (exit code {result.returncode})")
        print(f"  stderr: {result.stderr[:500]}")
        sys.exit(1)
    print("  Python script completed successfully")

    # Step 6: Snapshot AFTER PYTHON
    print("\n[6/7] Snapshot AFTER PYTHON")
    after_python = {}
    for t in tables:
        after_python[t] = snapshot_table(engine, t)
        print(f"  {t}: {len(after_python[t])} rows")

    # Step 7: DIFF
    print("\n[7/7] DIFF")
    all_identical = True
    for t in tables:
        d = diff_dataframes(after_ssis[t].copy(), after_python[t].copy(), key_cols, exclude_cols)
        if d["identical"]:
            print(f"  ✅ {t}: IDENTICAL ({d['ssis_rows']} rows)")
        else:
            all_identical = False
            print(f"  ❌ {t}: MISMATCH")
            print(f"     Rows: SSIS={d['ssis_rows']} Python={d['python_rows']}")
            for diff in d["diffs"]:
                print(f"     Column '{diff['column']}': {diff['count']} rows differ")
                for s in diff["samples"][:3]:
                    print(f"       Row {s['row']}: SSIS={s['ssis']} Python={s['python']}")

    # Verdict
    print("\n" + "=" * 60)
    if all_identical:
        print("  ✅ VERDICT: IDENTICAL — Python produces same output as SSIS")
    else:
        print("  ❌ VERDICT: DIFFERENCES FOUND — see details above")
    print("=" * 60)

    if exclude_cols:
        print(f"\n  Note: excluded from comparison: {', '.join(exclude_cols)}")

    sys.exit(0 if all_identical else 1)


if __name__ == "__main__":
    main()
