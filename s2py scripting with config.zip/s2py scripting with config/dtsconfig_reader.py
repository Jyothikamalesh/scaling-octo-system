"""
dtsconfig_reader.py — Read SSIS .dtsconfig files at runtime.

Generated Python scripts import this to load their config.
Deploy tool writes the .dtsconfig → Python reads it. Same file SSIS used.

Resolution order:
  1. Explicit path passed to load()
  2. --config CLI flag
  3. Same-name .dtsconfig next to the calling script
  4. Environment variables (SSIS_CONN_{name} for connections, SSIS_VAR_{name} for variables)

Usage:
    from dtsconfig_reader import load, get_engine

    config = load()                                          # auto-detect
    config = load("LoadCustomers.dtsconfig")                 # explicit path
    config = load()  # + env: SSIS_CONN_SourceDB=...         # env override

    engine = get_engine(config, "SourceDB")
    df = pd.read_sql("SELECT ...", engine)
"""

import os
import re
import sys
import argparse
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote_plus

try:
    from sqlalchemy import create_engine as _create_engine
    HAS_SQLALCHEMY = True
except ImportError:
    HAS_SQLALCHEMY = False


def _parse_dtsconfig(config_path: str) -> dict:
    """Parse a .dtsconfig XML file into {name: value} dict."""
    result = {"connections": {}, "variables": {}, "properties": {}}

    try:
        tree = ET.parse(config_path)
    except (ET.ParseError, FileNotFoundError) as e:
        print(f"WARNING: Could not parse {config_path}: {e}", file=sys.stderr)
        return result

    for elem in tree.iter():
        tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        if tag != "Configuration":
            continue

        config_path_attr = elem.attrib.get("Path", "")
        configured_type = elem.attrib.get("ConfiguredType", "")

        # Extract the configured value
        value = None
        for child in elem:
            child_tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            if child_tag == "ConfiguredValue" and child.text:
                value = child.text.strip()

        if value is None:
            continue

        # Connection manager configs
        # Path looks like: \Package.Connections[SourceDB].Properties[ConnectionString]
        conn_match = re.search(r'Connections\[([^\]]+)\].*?(?:Properties\[(\w+)\])?', config_path_attr)
        if conn_match:
            conn_name = conn_match.group(1)
            prop_name = conn_match.group(2) or "ConnectionString"
            if prop_name == "ConnectionString":
                result["connections"][conn_name] = value
            else:
                result["properties"][f"{conn_name}.{prop_name}"] = value
            continue

        # Variable configs
        # Path looks like: \Package.Variables[User::BatchSize].Properties[Value]
        var_match = re.search(r'Variables\[(?:User::)?([^\]]+)\]', config_path_attr)
        if var_match:
            result["variables"][var_match.group(1)] = value
            continue

        # Property configs
        # Path looks like: \Package.Properties[LoggingMode]
        prop_match = re.search(r'Properties\[([^\]]+)\]', config_path_attr)
        if prop_match:
            result["properties"][prop_match.group(1)] = value


    return result


def _find_config_file(script_file: str = None, package_name: str = None) -> str | None:
    """Auto-detect .dtsconfig file location."""

    # 1. CLI flag
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--config", default=None)
    args, _ = parser.parse_known_args()
    if args.config and os.path.exists(args.config):
        return args.config

    # 2. Same-name .dtsconfig next to the script
    if script_file:
        script_path = Path(script_file)
        candidates = [
            script_path.with_suffix(".dtsconfig"),
            script_path.parent / f"{script_path.stem}.dtsconfig",
        ]
        if package_name:
            candidates.append(script_path.parent / f"{package_name}.dtsconfig")
            # Also check a configs/ subdirectory
            candidates.append(script_path.parent / "configs" / f"{package_name}.dtsconfig")

        for c in candidates:
            if c.exists():
                return str(c)

    # 3. Check SSIS_CONFIG_PATH env var
    env_path = os.environ.get("SSIS_CONFIG_PATH")
    if env_path and os.path.exists(env_path):
        return env_path

    return None


def _apply_env_overrides(config: dict) -> dict:
    """Apply environment variable overrides on top of .dtsconfig values."""

    # SSIS_CONN_SourceDB overrides connections["SourceDB"]
    for key, val in os.environ.items():
        if key.startswith("SSIS_CONN_"):
            conn_name = key[10:]  # strip prefix
            config["connections"][conn_name] = val

    # SSIS_VAR_BatchSize overrides variables["BatchSize"]
    for key, val in os.environ.items():
        if key.startswith("SSIS_VAR_"):
            var_name = key[9:]
            config["variables"][var_name] = val

    return config


def load(config_path: str = None, package_name: str = None) -> dict:
    """
    Load config from .dtsconfig file with env var overrides.

    Args:
        config_path: Explicit path to .dtsconfig file (optional)
        package_name: Original SSIS package name for auto-detection (optional)

    Returns:
        {
            "connections": {"SourceDB": "Server=...;Database=...;...", ...},
            "variables": {"BatchSize": "1000", ...},
            "properties": {"LoggingMode": "Enabled", ...},
            "config_source": "path/to/file.dtsconfig"  or  "environment_only"
        }
    """
    # Find the config file
    if config_path is None:
        # Get the calling script's __file__ for auto-detection
        import inspect
        caller_file = None
        frame = inspect.currentframe().f_back
        if frame and frame.f_globals.get("__file__"):
            caller_file = frame.f_globals["__file__"]

        config_path = _find_config_file(caller_file, package_name)

    # Parse .dtsconfig if found
    if config_path and os.path.exists(config_path):
        config = _parse_dtsconfig(config_path)
        config["config_source"] = config_path
    else:
        config = {"connections": {}, "variables": {}, "properties": {}}
        config["config_source"] = "environment_only"

    # Apply env var overrides
    config = _apply_env_overrides(config)

    if not config["connections"] and not config["variables"]:
        print(
            "WARNING: No config loaded. Provide --config flag, "
            "place .dtsconfig next to script, or set SSIS_CONN_* env vars.",
            file=sys.stderr
        )

    return config


def get_engine(config: dict, connection_name: str):
    """
    Build SQLAlchemy engine from a connection name in the config.

    Handles OLEDB/ADO.NET connection strings by converting to pyodbc format.
    """
    if not HAS_SQLALCHEMY:
        raise ImportError("sqlalchemy required: pip install sqlalchemy pyodbc")

    cs = config.get("connections", {}).get(connection_name)
    if not cs:
        available = list(config.get("connections", {}).keys())
        raise ValueError(
            f"Connection '{connection_name}' not found in config. "
            f"Available: {available}"
        )

    # If it's already a SQLAlchemy URL, use directly
    if cs.startswith("mssql+") or cs.startswith("postgresql") or cs.startswith("sqlite"):
        return _create_engine(cs)

    # Convert OLEDB/ADO.NET connection string to pyodbc
    # Normalize common variations
    normalized = cs

    # Ensure ODBC driver is specified
    if "Driver=" not in normalized and "driver=" not in normalized:
        normalized += ";Driver=ODBC Driver 17 for SQL Server"

    # Map Provider= (OLEDB) → remove it (pyodbc doesn't use it)
    normalized = re.sub(r'Provider=[^;]+;?', '', normalized)

    # Map "Initial Catalog" → "Database"
    normalized = normalized.replace("Initial Catalog=", "Database=")

    # Map "Data Source" → "Server"
    normalized = normalized.replace("Data Source=", "Server=")

    # Map "Integrated Security=SSPI" → "Trusted_Connection=yes"
    normalized = re.sub(
        r'Integrated Security=\w+',
        'Trusted_Connection=yes',
        normalized
    )

    # Clean up double semicolons
    normalized = re.sub(r';+', ';', normalized).strip(';')

    return _create_engine(f"mssql+pyodbc:///?odbc_connect={quote_plus(normalized)}")


def get_variable(config: dict, var_name: str, default=None, cast_type=None):
    """Get a variable value from config, with optional type casting."""
    val = config.get("variables", {}).get(var_name, default)
    if val is not None and cast_type is not None:
        try:
            val = cast_type(val)
        except (ValueError, TypeError):
            pass
    return val


# ─── Quick self-test ───

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        path = sys.argv[1]
        config = load(path)
        print(f"Source: {config['config_source']}")
        print(f"\nConnections ({len(config['connections'])}):")
        for name, cs in config["connections"].items():
            # Mask password if present
            masked = re.sub(r'(Password=)[^;]+', r'\1****', cs)
            print(f"  {name}: {masked}")
        print(f"\nVariables ({len(config['variables'])}):")
        for name, val in config["variables"].items():
            print(f"  {name}: {val}")
        print(f"\nProperties ({len(config['properties'])}):")
        for name, val in config["properties"].items():
            print(f"  {name}: {val}")
    else:
        print("Usage: python dtsconfig_reader.py path/to/file.dtsconfig")
