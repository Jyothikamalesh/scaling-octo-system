# SSIS to Python — 1:1 Converter

Two scripts. No agents. No AI.

## Convert

```bash
# Single file
python dtsx_to_python.py LoadCustomerData.dtsx

# Single file with explicit config
python dtsx_to_python.py LoadCustomerData.dtsx --config LoadCustomerData.dtsconfig

# All .dtsx files in a folder
python dtsx_to_python.py ./ssis-packages/ --outdir ./python-output/
```

## Prove they're identical

```bash
pip install pandas sqlalchemy pyodbc

python prove_identical.py \
    --db "Server=prod-sql;Database=msdb;Trusted_Connection=yes" \
    --job "ETL_Load_Customer_Data" \
    --script ./python-output/LoadCustomerData.py \
    --tables "stg.Customers_US,stg.Customers_EU" \
    --keys "CustID" \
    --exclude-cols "LoadDate"
```

The proof script does:
1. Snapshot destination tables
2. Run SSIS via `sp_start_job`
3. Snapshot after SSIS
4. Restore tables to original state
5. Run Python script
6. Snapshot after Python
7. Diff row-by-row → **IDENTICAL** or shows exact differences

## What gets converted automatically

| SSIS Component | Python Output | Works? |
|---|---|---|
| ConnectionManager | `create_engine(connection_string)` | ✅ |
| ExecuteSQLTask | `conn.execute(text("exact same SQL"))` | ✅ |
| DataFlowTask source | `pd.read_sql("exact same SQL", engine)` | ✅ |
| DerivedColumn | `df["col"] = translated_expression` | ✅ |
| Lookup | `df.merge(lookup_df, on=[keys], how="left")` | ✅ |
| ConditionalSplit | `df[condition].copy()` | ✅ |
| Sort | `df.sort_values([cols])` | ✅ |
| UnionAll | `pd.concat([...])` | ✅ |
| DataConversion | `df["col"].astype(type)` | ✅ |
| RowCount | `len(df)` | ✅ |
| OLE DB Destination | `df.to_sql("table", engine)` | ✅ |
| Flat File Destination | `df.to_csv("path")` | ✅ |
| FileSystemTask | `shutil.move/copy/os.remove` | ✅ |
| ExecutePackageTask | `from child import main` | ✅ |
| SendMailTask | `smtplib` template | ✅ |
| Precedence Constraints | `if/try/except` in execution order | ✅ |
| Event Handlers (OnError) | `try/except` wrapper | ✅ |
| Variables | Python variables with same values | ✅ |
| SSIS Expressions | ~30 function translations (GETDATE, UPPER, etc.) | ✅ |
| **ScriptTask (C#/VB.NET)** | **`raise NotImplementedError`** | **❌ Manual** |

## What needs manual work

Only **Script Tasks** — these contain arbitrary C#/VB.NET code that can't be mechanically translated. The converter:
- Extracts the original code as comments
- Creates a function stub with `NotImplementedError`  
- You translate the C# logic to Python by hand (or ask Claude)

If your packages have zero Script Tasks, the conversion is 100% automated.

## Config — No Hardcoded Values

Generated scripts read the **same .dtsconfig file** that SSIS uses. Your deploy tool doesn't change.

```
TODAY (SSIS):     deploy tool → writes .dtsconfig → SSIS reads it
AFTER (Python):   deploy tool → writes .dtsconfig → Python reads it  (same file, zero changes)
```

Three ways to provide config at runtime:
```bash
# 1. Auto-detect: place .dtsconfig next to the .py file
ls ./
  LoadCustomers.py
  LoadCustomers.dtsconfig    ← auto-detected

# 2. Explicit flag
python LoadCustomers.py --config /deploy/configs/prod/LoadCustomers.dtsconfig

# 3. Environment variables (override or standalone)
export SSIS_CONN_SourceDB="Server=prod-sql;Database=CustomerDB;Trusted_Connection=yes"
python LoadCustomers.py
```

## Files

```
dtsx_to_python.py        ← The converter (run once)
dtsconfig_reader.py      ← Config reader (ships with generated scripts)
prove_identical.py       ← DB proof (run after conversion)
CONFIG_STRATEGY.md       ← Full comparison of config approaches
```

## Dependencies

```
pip install pandas sqlalchemy pyodbc
```
